% --------------------------------------------------------------------- %%
%  Cumulative Number of Averted HSV-1 Infections Across Four Scenarios
%  This script loads infection data for multiple vaccine efficacy (VE)
%  levels and vaccination strategies, then plots the cumulative number
%  of infections averted over time (2020�2100).
% ---------------------------------------------------------------------- %%

clear all
close all 
clc

load('TotalinfectedWV.mat')
load('S1Averted.mat')
AvertInfection50S1=AvertInfection50;
AvertInfection70S1=AvertInfection70;
AvertInfection90S1=AvertInfection90;
load('S2Averted.mat')
AvertInfection50S2=AvertInfection50;
AvertInfection70S2=AvertInfection70;
AvertInfection90S2=AvertInfection90;
load('S3Averted.mat')
AvertInfection50S3=AvertInfection50;
AvertInfection70S3=AvertInfection70;
AvertInfection90S3=AvertInfection90;
load('S4Averted.mat')
AvertInfection50S4=AvertInfection50;
AvertInfection70S4=AvertInfection70;
AvertInfection90S4=AvertInfection90;



years1=2020:2100;

figure,
subplot(2,2,1)
hold on 
h1=plot(years1,AvertInfection50S1./1000000,'b-','LineWidth',1.5)
h2=plot(years1,AvertInfection70S1./1000000,'g-','LineWidth',1.5)
h3=plot(years1,AvertInfection90S1./1000000,'r-','LineWidth',1.5)
plot(years1(1:11),AvertInfection90S1(1:11)./1000000,'k-','LineWidth',1.5)
xline(2030,'k--','LineWidth', 2)
legend('\itVE_s=50%','\itVE_s=70%','\itVE_s=90%','Orientation','horizontal') 
xlabel('Years','FontSize',8)
ylabel({'Cumulative number of averted HSV-1';'infections (millions)'},'FontSize',8)
title({'Scenario 1, infant vaccination with';'lifelong protection'},'FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8)
ts.Rotation = 90;
xlim([2020,2100])
ylim([0,120])
xticks([2020:10:2100])
set(gca,'FontSize',8)





subplot(2,2,2)
hold on 
h1=plot(years1,AvertInfection50S2./1000000,'b-','LineWidth',1.5)
h2=plot(years1,AvertInfection70S2./1000000,'g-','LineWidth',1.5)
h3=plot(years1,AvertInfection90S2./1000000,'r-','LineWidth',1.5)
plot(years1(1:11),AvertInfection90S2(1:11)./1000000,'k-','LineWidth',1.5)

xline(2030,'k--','LineWidth', 2)
legend('VE_s=50%','VE_s=70%','VE_s=90%') 
xlabel('Years','FontSize',8)
ylabel({'Cumulative number of averted HSV-1';'infections (millions)'},'FontSize',8)
title({'Scenario 2, infant and adolescent';'catch-up vaccination with';'lifelong protection'},'FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8)
ts.Rotation = 90;
xlim([2020,2100])
xticks([2020:10:2100])
ylim([0,120])
set(gca,'FontSize',8)


subplot(2,2,3)
hold on 
h1=plot(years1,AvertInfection50S3./1000000,'b-','LineWidth',1.5)
h2=plot(years1,AvertInfection70S3./1000000,'g-','LineWidth',1.5)
h3=plot(years1,AvertInfection90S3./1000000,'r-','LineWidth',1.5)
plot(years1(1:11),AvertInfection90S3(1:11)./1000000,'k-','LineWidth',1.5)
xline(2030,'k--','LineWidth', 2)
legend('VE_s=50%','VE_s=70%','VE_s=90%') 
xlabel('Years','FontSize',8)
ylabel({'Cumulative number of averted HSV-1';'infections (millions)'},'FontSize',8)
title({'Scenario 3, infant, adolescent catch-up,';'and adolescent booster vaccination';'with 15-year protection'},'FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8)
ts.Rotation = 90;
xlim([2020,2100])
xticks([2020:10:2100])
ylim([0,120])
set(gca,'FontSize',8)



subplot(2,2,4)
hold on 
h1=plot(years1,AvertInfection50S4./1000000,'b-','LineWidth',1.5)
h2=plot(years1,AvertInfection70S4./1000000,'g-','LineWidth',1.5)
h3=plot(years1,AvertInfection90S4./1000000,'r-','LineWidth',1.5)
plot(years1(1:11),AvertInfection90S4(1:11)./1000000,'k-','LineWidth',1.5)
xline(2030,'k--','LineWidth', 2)
legend('\itVE_s=50%','\itVE_s=70%','\itVE_s=90%') 
xlabel('Years','FontSize',8)
ylabel({'Cumulative number of averted HSV-1';'infections (millions)'},'FontSize',8)
title({'Scenario 4, infant vaccination with';' 15-year protection'},'FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8)
ts.Rotation = 90;
xlim([2020,2100])
xticks([2020:10:2100])
ylim([0,120])
set(gca,'FontSize',8)