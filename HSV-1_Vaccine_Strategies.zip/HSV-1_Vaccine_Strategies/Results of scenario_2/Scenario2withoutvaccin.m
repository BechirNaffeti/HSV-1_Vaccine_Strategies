clear all
close all 
clc
%% Fixed paramters
Nc=5;
Nr=3;
Nb=20;
e_AO=0.75; % e age oral 
e_ROS=0.3; % e risk oral sex
e_RSI=0.3;  % e risk sexual intercourse
e_AOS=0.7; % e age oral sex
e_ASI=0.7; % e sexual intercourse
Prob_Ioral=0.01; % HSV-1 transmission probability per act for an oral sex act
Prob_Igenital=0.01; %HSV-1 transmission probability per act for a sexual intercourse act
FrequencyOfCoitalActA=[3.90 3.50 3.20 2.90 2.50 2.20 1.90 1.50 1.20 0.87];  
FrequencyOfCoitalAct=zeros(20,1);
FrequencyOfCoitalAct(4:13)=365.*FrequencyOfCoitalActA/7; %%Per year
TranProb_O_OS= 1-((1-Prob_Ioral).^FrequencyOfCoitalAct)   ;%oral sex HSV-1 transmission probability per sexual partnership between a member in S and  I_Oral (oral sex)
TranProb_G_OS=1-((1-Prob_Ioral).^FrequencyOfCoitalAct)   ;%oral sex HSV-1 transmission probability per sexual partnership between a member in S and  I_Genital (oral sex)
TranProb_G_SI=1-((1-Prob_Igenital).^FrequencyOfCoitalAct); %Genital sex HSV-1 transmission probability per sexual partnership between a member in S and  I_Genital (genital sex)
eta=1/5;
theta=4.5;
Risk=1:3;
Pwlaw=Risk.^theta;
Xi_oral=0.137;%Oral HSV-1 shedding frequency
Xi_genital=0.0151;% Genetic HSV-1 shedding frequency
chi_oral=16.2; % Frequency of oral HSV-1 reactivations
chi_genital=0.7;% Frequency of Genital HSV-1 reactivations
pi_O= 365*(1/(((1-Xi_oral)/chi_oral)*365)); % 1/pi_O is the duration of latency between two oral reactivations
pi_G=365*(1/(((1-Xi_genital)/chi_genital)*365)); % 1/pi_G is the duration of latency between two genital reactivations
gama_O= 365*(1/(((Xi_oral)/chi_oral)*365)); %  1/gama_O is the duration of an oral reactivations
gama_G=365*(1/(((Xi_genital)/chi_genital)*365));%  1/gama_G is the duration of a genital reactivations
f_S_G=0.26; %Fraction of HSV-1 genital herpes infections that are symptomatic
a=1:Nb;
Psi=0.913.*exp(-((a-8.48)./8.317).^2);
Psi(1:3)=zeros(1,3);
C_SI=0.0102; % 
%% vaccin Paramters
vaccin_perd=0;
VE=0;
vaccinFraction1=0;
vaccinFraction2=0;
Vbirth=0;
%% import optimal set of paramters
values_1 = [0.0193524780680780,0.191983841953055*10^4,202.877050848782,1.50364017711900*10,0.712882576229875,0.514853119211157,0.176083059120317*10^4,162.966550317040];
a0 = values_1(1);
a1 = values_1(2);
a2 = values_1(3);
c0 = values_1(6);
c1 = values_1(7);
c2 = values_1(8);
c4 = values_1(4);
c3 = values_1(5);
Optimal=[a0 a1 a2 c0 c1 c2 c3 c4];
%% Create Initial solution
epsilon = 10^-6;
data_USA = readtable('Population Size Zoom.xlsx', 'ReadVariableNames', false);
year = str2double(table2array(data_USA(1:70, 1)));
numericData_total = table2array(data_USA(1:70, 23));
data_USA_numeric = table2array(data_USA(1:21, 2:21));
data_USA_numeric = str2double(data_USA_numeric);
B = data_USA_numeric(1,:);
Population=B;


RiskGroupPopulationFactors=[0.0794,0.6883,0.2304];
N_0=RiskGroupPopulationFactors.*(Population)';
Init_prevOral=0.3;
Init_prevGenital=0.15;
I_Oral=Init_prevOral.*N_0;
A_Oral=Init_prevOral.*N_0;
I_Genital= zeros(Nb,Nr);
I_Genital(4:20,:)=Init_prevGenital.*N_0(4:20,:);
A_Genital= zeros(Nb,Nr);
A_Genital(4:20,:)=Init_prevGenital.*N_0(4:20,:);
S0=N_0-(I_Oral+A_Oral+I_Genital+A_Genital);
S0=S0;




x0=[];
for b=1:Nb
    for i=1:Nr
        x0=[x0, S0(b,i),I_Oral(b,i),A_Oral(b,i),I_Genital(b,i),A_Genital(b,i)];
    end
end
SolInitial1=x0+epsilon;
SolInitial1=[SolInitial1,zeros(1,4*length(x0)),zeros(1,Nb)];


z=[0.249999970452327;24.9999982481145;1.81623881363446;0.199499999744568;0.00340000001604559]; %%Fitting Last Result (11/04/2018)
Xi_t=z(4)*1e4;
Xi_D=z(2);
Z=z(3);
Rou0=z(1);
C_OS=z(5);

t0=1750;
tf=2100;
dt=0.5;
tspan=t0:0.5:tf+dt;
[t,y]=ode15s(@ModelHSV1_vaccin, tspan,SolInitial1,[],Nc,Nr,Nb,vaccin_perd,vaccinFraction1,vaccinFraction2,Vbirth,VE,e_AO,e_ROS,e_RSI,e_AOS,e_ASI,Optimal,Pwlaw,eta,pi_O,pi_G,gama_O,gama_G,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI,Xi_t, Xi_D,Z,Rou0,C_OS,C_SI,Psi);
%% Results

S1=y(:,1:Nc:Nc*Nr*Nb);
IO1=y(:,2:Nc:Nc*Nr*Nb);
AO1=y(:,3:Nc:Nc*Nr*Nb);
IG1=y(:,4:Nc:Nc*Nr*Nb);
AG1=y(:,5:Nc:Nc*Nr*Nb);

V1=y(:,Nc*Nr*Nb+1:Nc:2*Nc*Nr*Nb);
IvO1=y(:,Nc*Nr*Nb+2:Nc:2*Nc*Nr*Nb);
AvO1=y(:,Nc*Nr*Nb+3:Nc:2*Nc*Nr*Nb);
IvG1=y(:,Nc*Nr*Nb+4:Nc:2*Nc*Nr*Nb);
AvG1=y(:,Nc*Nr*Nb+5:Nc:2*Nc*Nr*Nb);


Vb1=y(:,2*Nc*Nr*Nb+1:Nc:3*Nc*Nr*Nb);
IvbO1=y(:,2*Nc*Nr*Nb+2:Nc:3*Nc*Nr*Nb);
AvbO1=y(:,2*Nc*Nr*Nb+3:Nc:3*Nc*Nr*Nb);
IvbG1=y(:,2*Nc*Nr*Nb+4:Nc:3*Nc*Nr*Nb);
AvbG1=y(:,2*Nc*Nr*Nb+5:Nc:3*Nc*Nr*Nb);


Swp1=y(:,3*Nc*Nr*Nb+1:Nc:4*Nc*Nr*Nb);
IwpO1=y(:,3*Nc*Nr*Nb+2:Nc:4*Nc*Nr*Nb);
AwpO1=y(:,3*Nc*Nr*Nb+3:Nc:4*Nc*Nr*Nb);
IwpG1=y(:,3*Nc*Nr*Nb+4:Nc:4*Nc*Nr*Nb);
AwpG1=y(:,3*Nc*Nr*Nb+5:Nc:4*Nc*Nr*Nb);


Swb1=y(:,4*Nc*Nr*Nb+1:Nc:5*Nc*Nr*Nb);
IwbO1=y(:,4*Nc*Nr*Nb+2:Nc:5*Nc*Nr*Nb);
AwbO1=y(:,4*Nc*Nr*Nb+3:Nc:5*Nc*Nr*Nb);
IwbG1=y(:,4*Nc*Nr*Nb+4:Nc:5*Nc*Nr*Nb);
AwbG1=y(:,4*Nc*Nr*Nb+5:Nc:5*Nc*Nr*Nb);

PeopleVaccinated=y(:,5*Nc*Nr*Nb+1:5*Nc*Nr*Nb+Nb);


for b=1:Nb
    S(:,:,b)=S1(:,(b-1)*Nr+(1:3));
    IOral(:,:,b)=IO1(:,(b-1)*Nr+(1:3));
    AOral(:,:,b)=AO1(:,(b-1)*Nr+(1:3));
    IGenital(:,:,b)=IG1(:,(b-1)*Nr+(1:3));
    AGenital(:,:,b)=AG1(:,(b-1)*Nr+(1:3)); 
   
    
    V(:,:,b)=V1(:,(b-1)*Nr+(1:3));
    IvOral(:,:,b)=IvO1(:,(b-1)*Nr+(1:3));
    AvOral(:,:,b)=AvO1(:,(b-1)*Nr+(1:3));
    IvGenital(:,:,b)=IvG1(:,(b-1)*Nr+(1:3));
    AvGenital(:,:,b)=AvG1(:,(b-1)*Nr+(1:3)); 
    
    
    Vb(:,:,b)=Vb1(:,(b-1)*Nr+(1:3));
    IvbOral(:,:,b)=IvbO1(:,(b-1)*Nr+(1:3));
    AvbOral(:,:,b)=AvbO1(:,(b-1)*Nr+(1:3));
    IvbGenital(:,:,b)=IvbG1(:,(b-1)*Nr+(1:3));
    AvbGenital(:,:,b)=AvbG1(:,(b-1)*Nr+(1:3)); 
    
    
    Swp(:,:,b)=Swp1(:,(b-1)*Nr+(1:3));
    IwpOral(:,:,b)=IwpO1(:,(b-1)*Nr+(1:3));
    AwpOral(:,:,b)=AwpO1(:,(b-1)*Nr+(1:3));
    IwpGenital(:,:,b)=IwpG1(:,(b-1)*Nr+(1:3));
    AwpGenital(:,:,b)=AwpG1(:,(b-1)*Nr+(1:3)); 
    
    Swb(:,:,b)=Swb1(:,(b-1)*Nr+(1:3));
    IwbOral(:,:,b)=IwbO1(:,(b-1)*Nr+(1:3));
    AwbOral(:,:,b)=AwbO1(:,(b-1)*Nr+(1:3));
    IwbGenital(:,:,b)=IwbG1(:,(b-1)*Nr+(1:3));
    AwbGenital(:,:,b)=AwbG1(:,(b-1)*Nr+(1:3)); 
    
    
end

%% Prevalence Total

InfectedUnvaccinated=sum(sum(IOral,2)+sum(AOral,2)+sum(IGenital,2)+sum(AGenital,2),3);
InfectedPrimaryVaccination=sum(sum(IvOral,2)+sum(AvOral,2)+sum(IvGenital,2)+sum(AvGenital,2),3);
InfectedBoostVaccinated=sum(sum(IvbOral,2)+sum(AvbOral,2)+sum(IvbGenital,2)+sum(AvbGenital,2),3);
InfectedWanningPrimary=sum(sum(IwpOral,2)+sum(AwpOral,2)+sum(IwpGenital,2)+sum(AwpGenital,2),3);
InfectedWanningBoost=sum(sum(IwbOral,2)+sum(AwbOral,2)+sum(IwbGenital,2)+sum(AwbGenital,2),3);
PrevalenceTotal=100*(InfectedUnvaccinated+InfectedPrimaryVaccination+InfectedBoostVaccinated+InfectedWanningPrimary+InfectedWanningBoost)./sum(y(:,1:5*Nc*Nr*Nb),2);

EffectiveVaccinated=sum(sum(V,2)+sum(Vb,2),3)+InfectedPrimaryVaccination+InfectedBoostVaccinated;
EffectiveCoverage=100*EffectiveVaccinated./sum(y(:,1:5*Nc*Nr*Nb),2);
VaccineCoverage=100*(sum(PeopleVaccinated,2)./sum(y(:,1:5*Nc*Nr*Nb),2));
% plot(t,EffectiveCoverage)
% xlim([1920,2100])

% Incidence
TT=length(t);
% Lambda calculation
    for i=1:TT 
       Susceptible(:,:,i)=reshape(S(i,:,:),3,20)';             %susceptible unvaccinated
       SusceptiblePS(:,:,i)=reshape(V(i,:,:),3,20)';           % susceptible primary series vaccination
       SusceptibleB(:,:,i)=reshape(Vb(i,:,:),3,20)';           % susceptible boost vaccination
       SusceptibleWPS(:,:,i)=reshape(Swp(i,:,:),3,20)';               % susceptible waned immune protection of primary-series vaccination
       SusceptibleWB(:,:,i)=reshape(Swb(i,:,:),3,20)';               % susceptible waned immune protection of booster vaccination
       
       
       
       Xt=y(i,:);
       [dydt,lamOO,lamGO,lamOG,lamGG,EffvBirth,EffvPS,  EffVboost]=ModelHSV1_vaccin(t(i),Xt',Nc,Nr,Nb,vaccin_perd,vaccinFraction1,vaccinFraction2,Vbirth,VE,e_AO,e_ROS,e_RSI,e_AOS,e_ASI,Optimal,Pwlaw,eta,pi_O,pi_G,gama_O,gama_G,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI,Xi_t, Xi_D,Z,Rou0,C_OS,C_SI,Psi);
       
       lamOralOral(:,:,i)=lamOO;
       lamGenitalOral(:,:,i)=lamGO;
       lamGenitalGenital(:,:,i)=lamGG;
       lamOralGenital(:,:,i)=lamOG;
       
       
       lamOral(:,:,i)=lamOO+lamGO;
       lamGenital(:,:,i)=lamOG+lamGG;
       
        
       IncidenceGenital(i,:)=(sum(((lamGenital(:,:,i).*(Susceptible(:,:,i)+SusceptibleWPS(:,:,i)+SusceptibleWB(:,:,i)))+((1-VE)*lamGenital(:,:,i).*(SusceptiblePS(:,:,i)+SusceptibleB(:,:,i)))),2))'; 
       IncidenceOral(i,:)=(sum(((lamOral(:,:,i).*(Susceptible(:,:,i)+SusceptibleWPS(:,:,i)+SusceptibleWB(:,:,i)))+((1-VE)*lamOral(:,:,i).*(SusceptiblePS(:,:,i)+SusceptibleB(:,:,i)))),2))'; 
   
       EffectiveVaccinaBirth(i)=EffvBirth;
       EffectiveVaccinePrimarySeries(i)=EffvPS;
       EffectiveVaccineBoost(i)=EffVboost;
       
    end
%% incidence rate per year

IncG=sum(IncidenceGenital,2);
IncO=sum(IncidenceOral,2);
IncidenceGenitalyear(1)=IncG(1);
IncidenceOralyear(1)=IncO(1);
EffectiveVaccinaBirthyear(1)=EffectiveVaccinaBirth(1);
EffectiveVaccinePrimarySeriesyear(1)=EffectiveVaccinePrimarySeries(1);
 EffectiveVaccineBoostyear(1)=EffectiveVaccineBoost(1);
for j=t0+1:tf
IncidenceGenitalyear(j-t0+1) =trapz(IncG(2*(j-t0)+1:2*(j-t0+dt)+1));
IncidenceOralyear(j-t0+1) =trapz(IncO(2*(j-t0)+1:2*(j-t0+dt)+1));


EffectiveVaccinaBirthyear(j-t0+1)=trapz(EffectiveVaccinaBirth(2*(j-t0)+1:2*(j-t0+dt)+1));
EffectiveVaccinePrimarySeriesyear(j-t0+1)=trapz(EffectiveVaccinePrimarySeries(2*(j-t0)+1:2*(j-t0+dt)+1));
EffectiveVaccineBoostyear(j-t0+1)=trapz(EffectiveVaccineBoost(2*(j-t0)+1:2*(j-t0+dt)+1));
end



SusceptibleTotal=reshape(sum(sum(Susceptible+SusceptiblePS+SusceptibleB+SusceptibleWPS+SusceptibleWB,2)),length(t),1);
IncidenceGenitalrate= IncidenceGenitalyear' ./SusceptibleTotal(1:2:end);
IncidenceOralrate=  IncidenceOralyear'./SusceptibleTotal(1:2:end);
save('Withoutvaccin.mat','PrevalenceTotal','IncidenceGenitalyear','IncidenceOralyear','IncidenceGenitalrate','IncidenceOralrate','EffectiveCoverage','EffectiveVaccinaBirthyear','EffectiveVaccinePrimarySeriesyear','EffectiveVaccineBoostyear','VaccineCoverage','t')
       
% 
%   
