% ======================================================================= %
% HSV-1 vaccination scenarios: load outputs, compute reductions/averts,
% and visualize prevalence and NNV (number needed to vaccinate).
% This block adds comments for clarity without changing any code.
% ======================================================================= %


clear all
close all 
clc
% ----------------------------- Baseline ------------------------------- %
% No-vaccination scenario (WV) used as the reference for reductions

load('Withoutvaccin.mat')
PrevalenceTotalWV=PrevalenceTotal;
IncidenceGenitalyearWV=IncidenceGenitalyear;
IncidenceOralyearWV=IncidenceOralyear;
IncidenceGenitalrateWV=IncidenceGenitalrate;
IncidenceOralrateWV=IncidenceOralrate;
EffectiveVaccinaBirthWV=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesWV=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostWV=EffectiveVaccineBoostyear;
TotalinfectedWV=IncidenceGenitalyearWV+IncidenceOralyearWV;     
TotalvaccieWV=EffectiveVaccinaBirthWV+EffectiveVaccinePrimarySeriesWV+EffectiveVaccineBoostWV;

%% =============================== Scenario 1 ============================ %
% Infant vaccination with lifelong protection
load('Scenario1VE50.mat')
PrevalenceTotalVE50_1=PrevalenceTotal;
IncidenceGenitalyearVE50_1=IncidenceGenitalyear;
IncidenceOralyearVE50_1=IncidenceOralyear;
IncidenceGenitalrateVE50_1=IncidenceGenitalrate;
IncidenceOralrateVE50_1=IncidenceOralrate;
EffectiveVaccinaBirthVE50_1=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50_1=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50_1=EffectiveVaccineBoostyear;
TotalinfectedVE50_1=IncidenceGenitalyearVE50_1+IncidenceOralyearVE50_1;   
TotalvaccieVE50_1=EffectiveVaccinaBirthVE50_1+EffectiveVaccinePrimarySeriesVE50_1+EffectiveVaccineBoostVE50_1;
load('Scenario1VE70.mat')
PrevalenceTotalVE70_1=PrevalenceTotal;
IncidenceGenitalyearVE70_1=IncidenceGenitalyear;
IncidenceOralyearVE70_1=IncidenceOralyear;
IncidenceGenitalrateVE70_1=IncidenceGenitalrate;
IncidenceOralrateVE70_1=IncidenceOralrate;
EffectiveVaccinaBirthVE70_1=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70_1=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70_1=EffectiveVaccineBoostyear;
TotalinfectedVE70_1=IncidenceGenitalyearVE70_1+IncidenceOralyearVE70_1;   
TotalvaccieVE70_1=EffectiveVaccinaBirthVE70_1+EffectiveVaccinePrimarySeriesVE70_1+EffectiveVaccineBoostVE70_1;
load('Scenario1VE90.mat')
PrevalenceTotalVE90_1=PrevalenceTotal;
IncidenceGenitalyearVE90_1=IncidenceGenitalyear;
IncidenceOralyearVE90_1=IncidenceOralyear;
IncidenceGenitalrateVE90_1=IncidenceGenitalrate;
IncidenceOralrateVE90_1=IncidenceOralrate;
EffectiveVaccinaBirthVE90_1=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90_1=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90_1=EffectiveVaccineBoostyear;
TotalinfectedVE90_1=IncidenceGenitalyearVE90_1+IncidenceOralyearVE90_1;   
TotalvaccieVE90_1=EffectiveVaccinaBirthVE90_1+EffectiveVaccinePrimarySeriesVE90_1+EffectiveVaccineBoostVE90_1;
%% =============================== Scenario 2 ============================ %
% Infant + adolescent catch-up with lifelong protection
load('Scenario2VE50.mat')
PrevalenceTotalVE50_2=PrevalenceTotal;
IncidenceGenitalyearVE50_2=IncidenceGenitalyear;
IncidenceOralyearVE50_2=IncidenceOralyear;
IncidenceGenitalrateVE50_2=IncidenceGenitalrate;
IncidenceOralrateVE50_2=IncidenceOralrate;
EffectiveVaccinaBirthVE50_2=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50_2=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50_2=EffectiveVaccineBoostyear;
TotalinfectedVE50_2=IncidenceGenitalyearVE50_2+IncidenceOralyearVE50_2;   
TotalvaccieVE50_2=EffectiveVaccinaBirthVE50_2+EffectiveVaccinePrimarySeriesVE50_2+EffectiveVaccineBoostVE50_2;
load('Scenario2VE70.mat')
PrevalenceTotalVE70_2=PrevalenceTotal;
IncidenceGenitalyearVE70_2=IncidenceGenitalyear;
IncidenceOralyearVE70_2=IncidenceOralyear;
IncidenceGenitalrateVE70_2=IncidenceGenitalrate;
IncidenceOralrateVE70_2=IncidenceOralrate;
EffectiveVaccinaBirthVE70_2=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70_2=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70_2=EffectiveVaccineBoostyear;
TotalinfectedVE70_2=IncidenceGenitalyearVE70_2+IncidenceOralyearVE70_2;   
TotalvaccieVE70_2=EffectiveVaccinaBirthVE70_2+EffectiveVaccinePrimarySeriesVE70_2+EffectiveVaccineBoostVE70_2;
load('Scenario2VE90.mat')
PrevalenceTotalVE90_2=PrevalenceTotal;
IncidenceGenitalyearVE90_2=IncidenceGenitalyear;
IncidenceOralyearVE90_2=IncidenceOralyear;
IncidenceGenitalrateVE90_2=IncidenceGenitalrate;
IncidenceOralrateVE90_2=IncidenceOralrate;
EffectiveVaccinaBirthVE90_2=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90_2=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90_2=EffectiveVaccineBoostyear;
TotalinfectedVE90_2=IncidenceGenitalyearVE90_2+IncidenceOralyearVE90_2;   
TotalvaccieVE90_2=EffectiveVaccinaBirthVE90_2+EffectiveVaccinePrimarySeriesVE90_2+EffectiveVaccineBoostVE90_2;

%% =============================== Scenario 3 ============================ %
% Infant + adolescent catch-up + adolescent booster (15-year protection)
load('Scenario3VE50.mat')
PrevalenceTotalVE50_3=PrevalenceTotal;
IncidenceGenitalyearVE50_3=IncidenceGenitalyear;
IncidenceOralyearVE50_3=IncidenceOralyear;
IncidenceGenitalrateVE50_3=IncidenceGenitalrate;
IncidenceOralrateVE50_3=IncidenceOralrate;
EffectiveVaccinaBirthVE50_3=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50_3=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50_3=EffectiveVaccineBoostyear;
TotalinfectedVE50_3=IncidenceGenitalyearVE50_3+IncidenceOralyearVE50_3;   
TotalvaccieVE50_3=EffectiveVaccinaBirthVE50_3+EffectiveVaccinePrimarySeriesVE50_3+EffectiveVaccineBoostVE50_3;
load('Scenario3VE70.mat')
PrevalenceTotalVE70_3=PrevalenceTotal;
IncidenceGenitalyearVE70_3=IncidenceGenitalyear;
IncidenceOralyearVE70_3=IncidenceOralyear;
IncidenceGenitalrateVE70_3=IncidenceGenitalrate;
IncidenceOralrateVE70_3=IncidenceOralrate;
EffectiveVaccinaBirthVE70_3=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70_3=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70_3=EffectiveVaccineBoostyear;
TotalinfectedVE70_3=IncidenceGenitalyearVE70_3+IncidenceOralyearVE70_3;   
TotalvaccieVE70_3=EffectiveVaccinaBirthVE70_3+EffectiveVaccinePrimarySeriesVE70_3+EffectiveVaccineBoostVE70_3;
load('Scenario3VE90.mat')
PrevalenceTotalVE90_3=PrevalenceTotal;
IncidenceGenitalyearVE90_3=IncidenceGenitalyear;
IncidenceOralyearVE90_3=IncidenceOralyear;
IncidenceGenitalrateVE90_3=IncidenceGenitalrate;
IncidenceOralrateVE90_3=IncidenceOralrate;
EffectiveVaccinaBirthVE90_3=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90_3=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90_3=EffectiveVaccineBoostyear;
TotalinfectedVE90_3=IncidenceGenitalyearVE90_3+IncidenceOralyearVE90_3;   
TotalvaccieVE90_3=EffectiveVaccinaBirthVE90_3+EffectiveVaccinePrimarySeriesVE90_3+EffectiveVaccineBoostVE90_3;

%% =============================== Scenario 4 ============================ %
% Infant vaccination only (15-year protection)
load('Scenario4VE50.mat')
PrevalenceTotalVE50_4=PrevalenceTotal;
IncidenceGenitalyearVE50_4=IncidenceGenitalyear;
IncidenceOralyearVE50_4=IncidenceOralyear;
IncidenceGenitalrateVE50_4=IncidenceGenitalrate;
IncidenceOralrateVE50_4=IncidenceOralrate;
EffectiveVaccinaBirthVE50_4=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50_4=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50_4=EffectiveVaccineBoostyear;
TotalinfectedVE50_4=IncidenceGenitalyearVE50_4+IncidenceOralyearVE50_4;   
TotalvaccieVE50_4=EffectiveVaccinaBirthVE50_4+EffectiveVaccinePrimarySeriesVE50_4+EffectiveVaccineBoostVE50_4;
load('Scenario4VE70.mat')
PrevalenceTotalVE70_4=PrevalenceTotal;
IncidenceGenitalyearVE70_4=IncidenceGenitalyear;
IncidenceOralyearVE70_4=IncidenceOralyear;
IncidenceGenitalrateVE70_4=IncidenceGenitalrate;
IncidenceOralrateVE70_4=IncidenceOralrate;
EffectiveVaccinaBirthVE70_4=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70_4=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70_4=EffectiveVaccineBoostyear;
TotalinfectedVE70_4=IncidenceGenitalyearVE70_4+IncidenceOralyearVE70_4;   
TotalvaccieVE70_4=EffectiveVaccinaBirthVE70_4+EffectiveVaccinePrimarySeriesVE70_4+EffectiveVaccineBoostVE70_4;
load('Scenario4VE90.mat')
PrevalenceTotalVE90_4=PrevalenceTotal;
IncidenceGenitalyearVE90_4=IncidenceGenitalyear;
IncidenceOralyearVE90_4=IncidenceOralyear;
IncidenceGenitalrateVE90_4=IncidenceGenitalrate;
IncidenceOralrateVE90_4=IncidenceOralrate;
EffectiveVaccinaBirthVE90_4=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90_4=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90_4=EffectiveVaccineBoostyear;
TotalinfectedVE90_4=IncidenceGenitalyearVE90_4+IncidenceOralyearVE90_4;   
TotalvaccieVE90_4=EffectiveVaccinaBirthVE90_4+EffectiveVaccinePrimarySeriesVE90_4+EffectiveVaccineBoostVE90_4;

% --------------------------- Time settings ----------------------------- %
t0=1750;      % model start year
tf=2100;      % model end year
dt=0.5;       % time step (years)
years=[2050 2075 2100];  % reporting years for reductions

%% --------------------- Prevalence reductions by scenario --------------- %
% Relative reduction vs. baseline for each VE level at selected years
for j=1:3 
   % Scenario 1
   reductionPrevTotal50_1(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE50_1((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal70_1(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE70_1((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal90_1(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE90_1((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   % Scenario 2
   reductionPrevTotal50_2(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE50_2((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal70_2(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE70_2((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal90_2(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE90_2((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   % Scenario 3
   reductionPrevTotal50_3(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE50_3((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal70_3(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE70_3((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal90_3(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE90_3((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   % Scenario 4
   reductionPrevTotal50_4(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE50_4((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal70_4(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE70_4((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal90_4(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE90_4((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);

end

%% --------------------- Cumulative averted & NNV (2030?year) ------------ %
years1=2035:2100;  % years over which we report cumulative metrics
for j=1:length(years1)
    % Scenario 1: cumulative infections averted, vaccinations, and NNV
    CumulativeAvertInfection50_1(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50_1(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination50_1(j)=sum(TotalvaccieVE50_1(2030-t0+1:years1(j)-t0+1));
    Avert50_1(j)=CumulativeVaccination50_1(j)/ CumulativeAvertInfection50_1(j);
    
    CumulativeAvertInfection70_1(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70_1(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination70_1(j)=sum(TotalvaccieVE70_1(2030-t0+1:years1(j)-t0+1));
    Avert70_1(j)=CumulativeVaccination70_1(j)/ CumulativeAvertInfection70_1(j);
    
    
    CumulativeAvertInfection90_1(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90_1(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination90_1(j)=sum(TotalvaccieVE90_1(2030-t0+1:years1(j)-t0+1));
    Avert90_1(j)=CumulativeVaccination90_1(j)/ CumulativeAvertInfection90_1(j);
    
     % Scenario 2: cumulative infections averted, vaccinations, and NNV
    CumulativeAvertInfection50_2(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50_2(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination50_2(j)=sum(TotalvaccieVE50_2(2030-t0+1:years1(j)-t0+1));
    Avert50_2(j)=CumulativeVaccination50_2(j)/ CumulativeAvertInfection50_2(j);
    
    
     CumulativeAvertInfection70_2(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70_2(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination70_2(j)=sum(TotalvaccieVE70_2(2030-t0+1:years1(j)-t0+1));
     Avert70_2(j)=CumulativeVaccination70_2(j)/ CumulativeAvertInfection70_2(j);
    
    
     CumulativeAvertInfection90_2(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90_2(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination90_2(j)=sum(TotalvaccieVE90_2(2030-t0+1:years1(j)-t0+1));
     Avert90_2(j)=CumulativeVaccination90_2(j)/ CumulativeAvertInfection90_2(j);
    
     % Scenario 3: cumulative infections averted, vaccinations, and NNV
     CumulativeAvertInfection50_3(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50_3(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination50_3(j)=sum(TotalvaccieVE50_3(2030-t0+1:years1(j)-t0+1));
     Avert50_3(j)=CumulativeVaccination50_3(j)/ CumulativeAvertInfection50_3(j);
    
    
     CumulativeAvertInfection70_3(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70_3(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination70_3(j)=sum(TotalvaccieVE70_3(2030-t0+1:years1(j)-t0+1));
     Avert70_3(j)=CumulativeVaccination70_3(j)/ CumulativeAvertInfection70_3(j);
    
    
     CumulativeAvertInfection90_3(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90_3(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination90_3(j)=sum(TotalvaccieVE90_3(2030-t0+1:years1(j)-t0+1));
     Avert90_3(j)=CumulativeVaccination90_3(j)/ CumulativeAvertInfection90_3(j);
    
      % Scenario 4: cumulative infections averted, vaccinations, and NNV
     CumulativeAvertInfection50_4(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50_4(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination50_4(j)=sum(TotalvaccieVE50_4(2030-t0+1:years1(j)-t0+1));
     Avert50_4(j)=CumulativeVaccination50_4(j)/ CumulativeAvertInfection50_4(j);
    
    
     CumulativeAvertInfection70_4(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70_4(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination70_4(j)=sum(TotalvaccieVE70_4(2030-t0+1:years1(j)-t0+1));
     Avert70_4(j)=CumulativeVaccination70_4(j)/ CumulativeAvertInfection70_4(j);
    
    
     CumulativeAvertInfection90_4(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90_4(2030-t0+1:years1(j)-t0+1));
     CumulativeVaccination90_4(j)=sum(TotalvaccieVE90_4(2030-t0+1:years1(j)-t0+1));
     Avert90_4(j)=CumulativeVaccination90_4(j)/ CumulativeAvertInfection90_4(j);
      
end

%% ----------------------- Prevalence time-series plots ------------------ %
% Four panels (A�D): prevalence trajectories for scenarios 1�4
% Vertical line marks vaccine introduction year (2030)
subplot(2,2,1)
hold on
h2=plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE50_1((1950-t0+0.5)*2:end),'b','LineWidth',1.5)
h3=plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE70_1((1950-t0+0.5)*2:end),'g','LineWidth',1.5)
h4=plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE90_1((1950-t0+0.5)*2:end),'r','LineWidth',1.5)
h1=plot(t((1950-t0+0.5)*2:end),PrevalenceTotalWV((1950-t0+0.5)*2:end),'k','LineWidth',1.5)
xline(2030,'k--','LineWidth', 2);
ylabel({'HSV-1 prevalence in the total U.S. population (%)'},'FontSize',8)
xlabel('Year','FontSize',8)
xlim([2020,2100])
ylim([0,70])
title('(A)')
legend([h1 h2 h3 h4], ...
       'No vaccination', ...
       '\itVE_s=50%', ...
       '\itVE_s=70%', ...
       '\itVE_s=90%',...
        'Orientation','horizontal');
xticks(2020:20:2100)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
title('Scenario 1, infant vaccination with lifelong protection','FontSize',8)
set(gca,'FontSize',8)


subplot(2,2,2)
hold on
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE50_2((1950-t0+0.5)*2:end),'b','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE70_2((1950-t0+0.5)*2:end),'g','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE90_2((1950-t0+0.5)*2:end),'r','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalWV((1950-t0+0.5)*2:end),'k','LineWidth',1.5)
xline(2030,'k--','LineWidth', 2);
ylabel({'HSV-1 prevalence in the total U.S. population (%)'},'FontSize',8)
xlabel('Year','FontSize',8)
xlim([2020,2100])
ylim([0,70])
%legend('No vaccination','\itVE_s^O=VE_s^G=50%\rm','\itVE_s^O=VE_s^G=70%\rm','\itVE_s^O=VE_s^G=90%\rm')
xticks(2020:20:2100)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
title('Scenario 2, infant and adolescent catch-up vaccination with lifelong protection','FontSize',8)
set(gca,'FontSize',8)

subplot(2,2,3)
hold on
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE50_3((1950-t0+0.5)*2:end),'b','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE70_3((1950-t0+0.5)*2:end),'g','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE90_3((1950-t0+0.5)*2:end),'r','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalWV((1950-t0+0.5)*2:end),'k','LineWidth',1.5)


xline(2030,'k--','LineWidth', 2);
ylabel({'HSV-1 prevalence in the total U.S. population (%)'})
xlabel('Year','FontSize',8)
xlim([2020,2100])
ylim([0,70])

%legend('No vaccination','\itVE_s^O=VE_s^G=50%\rm','\itVE_s^O=VE_s^G=70%\rm','\itVE_s^O=VE_s^G=90%\rm')
xticks(2020:20:2100)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
title('Scenario 3, infant, adolescent catch-up, and adolescent booster vaccination with 15-year protection','FontSize',8)
set(gca,'FontSize',8)


subplot(2,2,4)
hold on
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE50_4((1950-t0+0.5)*2:end),'b','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE70_4((1950-t0+0.5)*2:end),'g','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalVE90_4((1950-t0+0.5)*2:end),'r','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:end),PrevalenceTotalWV((1950-t0+0.5)*2:end),'k','LineWidth',1.5)


xline(2030,'k--','LineWidth', 2);
ylabel({'HSV-1 prevalence in the total U.S. population (%)'})
xlabel('Year','FontSize',8)
xlim([2020,2100])
ylim([0,70])
%legend('No vaccination','\itVE_s^O=VE_s^G=50%\rm','\itVE_s^O=VE_s^G=70%\rm','\itVE_s^O=VE_s^G=90%\rm')
xticks(2020:20:2100)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
title('Scenario 4, infant vaccination with 15-year protection')
set(gca,'FontSize',8)
%% ===================== NNV (Avert) bar charts by scenario ============== %
% Bars at years 2040:10:2100 with labels rotated 90� and one decimal.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure
subplot(2,2,1)
hold on
V1=[6:10:length(years1)];
V2=[Avert50_1(V1)',Avert70_1(V1)',Avert90_1(V1)'];
AvertS1=V2;
p1=bar(V2,'BarWidth',1);
xlabel('Year','FontSize', 8)
ylabel({'Number needed to vaccinate to prevent';'one HSV-1 infection'},'FontSize', 8)
xtick111=[1 2 3 4 5 6 7 ];
xt1={'2040';'2050';'2060';'2070';'2080';'2090';'2100'};
set(gca,'xtick',xtick111); 
set(gca,'xticklabel',xt1);
set(gca, 'FontSize', 8)
ax = gca;
ax.YGrid = 'off';
ax.GridLineStyle = '-';
title('A','FontSize', 8)
yticks(0:10:120)
legend('\itVE_s=50%','\itVE_s=70%','\itVE_s=90%','Orientation','horizontal')
ylim([0,70])
[numCategories, numGroups] = size(V2);
for i = 1:numCategories
    for j = 1:numGroups
       
        text(i, V2(i,j)+0.2, num2str(V2(i,j),'%.1f'), 'HorizontalAlignment', 'center','FontSize',8,'Rotation', 90);
    end
end
title({'Scenario 1, infant vaccination with';'lifelong protection'},'FontSize', 8)


subplot(2,2,2)
hold on
V1=[6:10:length(years1)];
V2=[Avert50_2(V1)',Avert70_2(V1)',Avert90_2(V1)'];
AvertS2=V2;
p1=bar(V2,'BarWidth', 1);
xlabel('Year','FontSize', 8)
ylabel({'Number needed to vaccinate to prevent';'one HSV-1 infection'},'FontSize', 8)
xtick111=[1 2 3 4 5 6 7 ];
xt1={'2040';'2050';'2060';'2070';'2080';'2090';'2100'};
set(gca,'xtick',xtick111); 
set(gca,'xticklabel',xt1);
set(gca, 'FontSize', 8)
ax = gca;
ax.YGrid = 'off';
ax.GridLineStyle = '-';
title('(A)')
yticks(0:10:120)
legend('\itVE_s50%','\itVE_s70%','\itVE_s=90%','FontSize', 8)
ylim([0,70])
[numCategories, numGroups] = size(V2);
for i = 1:numCategories
    for j = 1:numGroups
       
        text(i, V2(i,j)+0.2, num2str(V2(i,j),'%.1f'), 'HorizontalAlignment', 'center','FontSize',8,'Rotation', 90);
    end
end
title({'Scenario 2, infant and adolescent';'catch-up vaccination with';'lifelong protection'},'FontSize', 8)

subplot(2,2,3)
hold on
V1=[6:10:length(years1)];
V2=[Avert50_3(V1)',Avert70_3(V1)',Avert90_3(V1)'];
AvertS3=V2;
p1=bar(V2,'BarWidth', 1);
xlabel('Year','FontSize', 8)
ylabel({'Number needed to vaccinate to prevent';'one HSV-1 infection'},'FontSize', 8)
xtick111=[1 2 3 4 5 6 7 ];
xt1={'2040';'2050';'2060';'2070';'2080';'2090';'2100'};
set(gca,'xtick',xtick111); 
set(gca,'xticklabel',xt1);
set(gca, 'FontSize',8)
ax = gca;
ax.YGrid = 'off';
ax.GridLineStyle = '-';
title('(C)')
yticks(0:10:120)
legend('\itVE_s=50%','\itVE_s=70%','\itVE_s=90%')
ylim([0,70])
[numCategories, numGroups] = size(V2);
for i = 1:numCategories
    for j = 1:numGroups
       
        text(i, V2(i,j)+0.2, num2str(V2(i,j),'%.1f'), 'HorizontalAlignment', 'center','FontSize',8,'Rotation', 90);
    end
end
title({'Scenario 3, infant, adolescent catch-up,';'and adolescent booster vaccination';'with 15-year protection'},'FontSize', 8)


subplot(2,2,4)
hold on
V1=[6:10:length(years1)];
V2=[Avert50_4(V1)',Avert70_4(V1)',Avert90_4(V1)'];
AvertS4=V2;
p1=bar(V2,'BarWidth', 1);
xlabel('Year','FontSize', 8)
ylabel({'Number needed to vaccinate to prevent';'one HSV-1 infection'},'FontSize', 8)
xtick111=[1 2 3 4 5 6 7 ];
xt1={'2040';'2050';'2060';'2070';'2080';'2090';'2100'};
set(gca,'xtick',xtick111); 
set(gca,'xticklabel',xt1);
set(gca, 'FontSize', 8)
ax = gca;
ax.YGrid = 'off';
ax.GridLineStyle = '-';
title('(D)')
yticks(0:10:120)
legend('\itVE_s=50%','\itVE_s=70%','\itVE_s=90%')
ylim([0,70])
[numCategories, numGroups] = size(V2);
for i = 1:numCategories
    for j = 1:numGroups
       
        text(i, V2(i,j)+0.2, num2str(V2(i,j),'%.1f'), 'HorizontalAlignment', 'center','FontSize',8,'Rotation', 90);
    end
end
title({'Scenario 4, infant vaccination with';'15-year protection'})
%% save results
save('Avert.mat','AvertS1','AvertS2','AvertS3','AvertS4')