function [lamOO,lamGO,lamOG,lamGG]= lambda(t,I_Oral,I_Genital,Iv_Oral,Iv_Genital,Ivb_Oral,Ivb_Genital,Iwp_Oral,Iwp_Genital,Iwb_Oral,Iwb_Genital,Nr,Nb,P,Rou_Oral,Rou_OS,Rou_SI,G_OralSex,G_SexualInter,H_Oral,H_OralSex,H_SexualInter,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI) 
%LAMBDA Compute forces of infection by route and source.
%
% Outputs (Nb x Nr each; age x risk):
%   lamOO : Oral acquisition from oral source
%   lamGO : Oral acquisition from genital source
%   lamOG : Genital acquisition from oral source
%   lamGG : Genital acquisition from genital source
%% ---------- Oral acquisition from oral source (lamOO) ----------
% For each recipient age a and risk i:
lamOO=zeros(Nb,Nr); 
for a=1:Nb
    for i=1:Nr 
       lamOO(a,i)=Rou_Oral.* sum((H_Oral(a,:)').*((I_Oral(:,i)+Iv_Oral(:,i)+Ivb_Oral(:,i)+Iwp_Oral(:,i)+Iwb_Oral(:,i))./P(:,i)));
    end
end
%% ---------- Oral acquisition from genital source (lamGO) ----------
lamGO=zeros(Nb,Nr);
for a=4:20
  for i=1:Nr
     lamGO(a,i)=Rou_OS(a,i).*sum(((TranProb_G_OS.*(H_OralSex(a,:)')).*sum((( G_OralSex(i,:).*(Rou_OS.*(I_Genital+Iv_Genital+Ivb_Genital + Iwp_Genital+Iwb_Genital)))./(P.*Rou_OS+10^-10)),2)));
  end
end
%% ---------- Genital acquisition from oral source (lamOG) ----------
lamOG=zeros(Nb,Nr);
for a=4:20
  for i=1:Nr
     lamOG(a,i)=Rou_OS(a,i).*sum(((TranProb_O_OS.*(H_OralSex(a,:)')).*sum((( Rou_OS.*G_OralSex(i,:).*(I_Oral+Iv_Oral+Ivb_Oral+Iwp_Oral+Iwb_Oral))./(P.*Rou_OS+10^-10)),2)));
  end
end
%% ---------- Genital acquisition from genital source (lamGG) ----------
lamGG=zeros(Nb,Nr);
for a=4:20
  for i=1:Nr
     lamGG(a,i)=Rou_SI(a,i).*sum(((TranProb_G_SI.*(H_SexualInter(a,:)')).*sum((G_SexualInter(i,:).*(Rou_SI.*(I_Genital+Iv_Genital+Ivb_Genital+Iwp_Genital+Iwb_Genital))./(P.*Rou_SI+10^-10)),2)));
  end
end
