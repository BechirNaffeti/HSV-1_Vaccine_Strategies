function [dydt,lamOO,lamGO,lamOG,lamGG,VB,VPS,Vb] = ModelHSV1_vaccin(t,y,Nc,Nr,Nb,vaccin_perd,vaccinFraction1,vaccinFraction2,Vbirth1,VE,e_AO,e_ROS,e_RSI,e_AOS,e_ASI,Optimal,Pwlaw,eta,pi_O,pi_G,gama_O,gama_G,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI,Xi_t, Xi_D,Z,Rou0,C_OS,C_SI,Psi)
%% Vaccination schedule and target age group
if (t<2030)
    % No vaccination
   vaccin_Rate=zeros(1,20);
   Vbirth=0;
   vaccin_Rateb=zeros(1,20);
elseif (t<=2040)
    % Start birth vaccination + catch-up at age group 3
    vaccin_Rate=vaccinFraction1.*[zeros(1,2),1,zeros(1,17)];
    Vbirth=Vbirth1;
    vaccin_Rateb=zeros(1,20);
else
    % Continue birth vaccination+ start booster at age group 3
    vaccin_Rateb=vaccinFraction2.*[zeros(1,2),1,zeros(1,17)];
    Vbirth=Vbirth1;
    vaccin_Rate=zeros(1,20);
end
%% Time-varying contact rates
Rou_Oral=Rou0.*(1+(Z./(1+exp((t-Xi_t)/Xi_D))));
Rou_OS=C_OS.*(Psi').*Pwlaw;
Rou_SI=C_SI.*(Psi').*Pwlaw;
%% --- Reshape y into age*risk matrices. 
% Unvaccinated
S=(reshape(y(1:Nc:Nc*Nb*Nr),Nr,Nb))';
I_Oral=(reshape(y(2:Nc:Nc*Nb*Nr),Nr,Nb))';
A_Oral=(reshape(y(3:Nc:Nc*Nb*Nr),Nr,Nb))';
I_Genital=(reshape(y(4:Nc:Nc*Nb*Nr),Nr,Nb))';
A_Genital=(reshape(y(5:Nc:Nc*Nb*Nr),Nr,Nb))';
% Primary series vaccination
V=(reshape(y(Nc*Nb*Nr+1:Nc:2*Nc*Nb*Nr),Nr,Nb))';
Iv_Oral=(reshape(y(Nc*Nb*Nr+2:Nc:2*Nc*Nb*Nr),Nr,Nb))';
Av_Oral=(reshape(y(Nc*Nb*Nr+3:Nc:2*Nc*Nb*Nr),Nr,Nb))';
Iv_Genital=(reshape(y(Nc*Nb*Nr+4:Nc:2*Nc*Nb*Nr),Nr,Nb))';
Av_Genital=(reshape(y(Nc*Nb*Nr+5:Nc:2*Nc*Nb*Nr),Nr,Nb))';
% Booster vaccination
Vb=(reshape(y(2*Nc*Nb*Nr+1:Nc:3*Nc*Nb*Nr),Nr,Nb))';
Ivb_Oral=(reshape(y(2*Nc*Nb*Nr+2:Nc:3*Nc*Nb*Nr),Nr,Nb))';
Avb_Oral=(reshape(y(2*Nc*Nb*Nr+3:Nc:3*Nc*Nb*Nr),Nr,Nb))';
Ivb_Genital=(reshape(y(2*Nc*Nb*Nr+4:Nc:3*Nc*Nb*Nr),Nr,Nb))';
Avb_Genital=(reshape(y(2*Nc*Nb*Nr+5:Nc:3*Nc*Nb*Nr),Nr,Nb))';
% Waned immune protection following primary-series vaccination
Swp=(reshape(y(3*Nc*Nb*Nr+1:Nc:4*Nc*Nb*Nr),Nr,Nb))';
Iwp_Oral=(reshape(y(3*Nc*Nb*Nr+2:Nc:4*Nc*Nb*Nr),Nr,Nb))';
Awp_Oral=(reshape(y(3*Nc*Nb*Nr+3:Nc:4*Nc*Nb*Nr),Nr,Nb))';
Iwp_Genital=(reshape(y(3*Nc*Nb*Nr+4:Nc:4*Nc*Nb*Nr),Nr,Nb))';
Awp_Genital=(reshape(y(3*Nc*Nb*Nr+5:Nc:4*Nc*Nb*Nr),Nr,Nb))';
% Waned immune protection following booster vaccination
Swb=(reshape(y(4*Nc*Nb*Nr+1:Nc:5*Nc*Nb*Nr),Nr,Nb))';
Iwb_Oral=(reshape(y(4*Nc*Nb*Nr+2:Nc:5*Nc*Nb*Nr),Nr,Nb))';
Awb_Oral=(reshape(y(4*Nc*Nb*Nr+3:Nc:5*Nc*Nb*Nr),Nr,Nb))';
Iwb_Genital=(reshape(y(4*Nc*Nb*Nr+4:Nc:5*Nc*Nb*Nr),Nr,Nb))';
Awb_Genital=(reshape(y(4*Nc*Nb*Nr+5:Nc:5*Nc*Nb*Nr),Nr,Nb))';
%%  population at each age and risk group
P=S+I_Oral+I_Genital+A_Oral+A_Genital+V+Iv_Oral+Iv_Genital+Av_Oral+Av_Genital+Vb+Ivb_Oral+Ivb_Genital+Avb_Oral+Avb_Genital+Swp+Iwp_Oral+Iwp_Genital+Awp_Oral+Awp_Genital+Swb+Iwb_Oral+Iwb_Genital+Awb_Oral+Awb_Genital;
%% Etape 1: Determination of the sexuel mixing matrix G
deltaRisk=eye(Nr);
ROUX_OS=Rou_OS.*P;
ROUX_SI=Rou_SI.*P;
G_OralSex=zeros(Nr,Nr);
G_OralSex=(e_ROS.*deltaRisk)+(1- e_ROS).*(sum(ROUX_OS)./sum(sum(ROUX_OS,2)));
G_SexualInter=zeros(Nr,Nr);
G_SexualInter=(e_RSI.*deltaRisk) +(1- e_RSI).*(sum(ROUX_SI)./sum(sum(ROUX_SI,2)));            
%% Etape 2: Determination of the age mixing matrix H
deltaAge=eye(Nb);
ROUX_Oral=Rou_Oral.*P;
H_OralSex=zeros(Nb,Nb);
H_SexualInter=zeros(Nb,Nb);
H_Oral=(e_AO*deltaAge)+((1-e_AO).* (sum(ROUX_Oral,2)')./sum(sum(ROUX_Oral,2)));
H_OralSex=(e_AOS*deltaAge)+((1-e_AOS).* ((sum(ROUX_OS,2))')./sum(sum(ROUX_OS,2)));
H_OralSex(1:3,:)=zeros(3,Nb);
H_OralSex(:,1:3)=zeros(Nb,3);
H_SexualInter=(e_ASI*deltaAge)+((1-e_ASI).* (sum(ROUX_SI,2)')./sum(sum(ROUX_SI,2)));
H_SexualInter(1:3,:)=zeros(3,Nb);
H_SexualInter(:,1:3)=zeros(Nb,3);
%% --- Forces of infection by route+source: lambda 
[lamOO,lamGO,lamOG,lamGG]=lambda(t,I_Oral,I_Genital,Iv_Oral,Iv_Genital,Ivb_Oral,Ivb_Genital,Iwp_Oral,Iwp_Genital,Iwb_Oral,Iwb_Genital,Nr,Nb,P,Rou_Oral,Rou_OS,Rou_SI,G_OralSex,G_SexualInter,H_Oral,H_OralSex,H_SexualInter,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI) ;
lamOral=lamOO+lamGO;
lamGenital=lamOG+lamGG;
%% Demography time-varying birth and age-specific mortality rates
Birth_rate=Birth_Function(t,Optimal(:,1),Optimal(:,2),Optimal(:,3));
Mortality_rate=Mortality_Function(t,1:Nb,Optimal(:,4),Optimal(:,5),Optimal(:,6),Optimal(:,7),Optimal(:,8));
%% Model  
dx=zeros((5*Nc*Nr*Nb)+Nb,1);
xt=y;
N=sum(P);
i=1:Nr;
dVPS=zeros(1,Nb);
dVB=zeros(1,Nb);
b=1;
%Unvaccinated
dx((b-1)*Nc*Nr+(i-1)*Nc+1)=((1-Vbirth)*Birth_rate.*N')-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+1));
dx((b-1)*Nc*Nr+(i-1)*Nc+2)=((lamOral(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+2));
dx((b-1)*Nc*Nr+(i-1)*Nc+3)=(gama_O.*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,1).*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+3));
dx((b-1)*Nc*Nr+(i-1)*Nc+4)=((lamGenital(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+4));
dx((b-1)*Nc*Nr+(i-1)*Nc+5)=(gama_G.*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+5));
%Primary series vaccination
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)= (Vbirth*Birth_rate.*N')+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamOral(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamGenital(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=((1-VE)*(lamOral(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(gama_O.*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=((1-VE).*(lamGenital(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(gama_G.*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Booster vaccination
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamOral(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamGenital(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((1-VE)*(lamOral(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O.*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((1-VE).*(lamGenital(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Waned immune protection following primary-series vaccination
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((lamOral(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(pi_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((lamGenital(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(pi_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Waned immune protection following booster vaccination
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((lamOral(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(pi_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((lamGenital(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(pi_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
%%%%%%%%%%%%%%%%%%%%%%%
 % Total number of people vaccinated at birth
VB=sum(Vbirth*Birth_rate.*N');  
% Total number of individuals vaccinated via primary (catch-up) series
dVPS(b)=sum(vaccin_Rate(b)*(xt((b-1)*Nc*Nr+(i-1)*Nc+1)+xt((b-1)*Nc*Nr+(i-1)*Nc+2)+xt((b-1)*Nc*Nr+(i-1)*Nc+3)+xt((b-1)*Nc*Nr+(i-1)*Nc+4)+xt((b-1)*Nc*Nr+(i-1)*Nc+5)));% vaccine primari series
% Total number of individuals vaccinated via booster doses
dVb(b)= sum(vaccin_Rateb(b)*(xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)));
% Total number of people vaccinated
dx(5*Nc*Nr*Nb+b)=VB+dVPS(b)-(Mortality_rate(:,b).*xt(5*Nc*Nr*Nb+b))-(eta.*xt(5*Nc*Nr*Nb+b));
for b=2:Nb   
%Unvaccinated
dx((b-1)*Nc*Nr+(i-1)*Nc+1)= (eta*xt((b-2)*Nc*Nr+(i-1)*Nc+1))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+1));
dx((b-1)*Nc*Nr+(i-1)*Nc+2)= (eta*xt((b-2)*Nc*Nr+(i-1)*Nc+2))+((lamOral(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+2));
dx((b-1)*Nc*Nr+(i-1)*Nc+3)= (eta*xt((b-2)*Nc*Nr+(i-1)*Nc+3))+(gama_O.*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+3));
dx((b-1)*Nc*Nr+(i-1)*Nc+4)= (eta*xt((b-2)*Nc*Nr+(i-1)*Nc+4))+((lamGenital(b,:)').*xt((b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+4));
dx((b-1)*Nc*Nr+(i-1)*Nc+5)= (eta*xt((b-2)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+5));
%Primary series vaccination
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(eta*xt(Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+1))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamOral(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamGenital(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_Rateb(b)*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(eta*xt(Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+2))+((1-VE)*(lamOral(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_Rateb(b)*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)= (eta*xt(Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+3))+(gama_O.*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_Rateb(b)*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(eta*xt(Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+4))+((1-VE)*(lamGenital(b,:)').*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_Rateb(b)*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(eta*xt(Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+(vaccin_Rate(b)*xt((b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_Rateb(b)*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Booster vaccination
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(eta*xt(2*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+1))+(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamOral(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((1-VE)*(lamGenital(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(eta*xt(2*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+2))+(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((1-VE)*(lamOral(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(eta*xt(2*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+3))+(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O.*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(pi_O*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(eta*xt(2*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+4))+(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((1-VE).*(lamGenital(b,:)').*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(eta*xt(2*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+5))+(vaccin_Rateb(b).*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(pi_G*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Waned immune protection following primary-series vaccination
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(eta*xt(3*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+1))+(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(eta*xt(3*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+2))+(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((lamOral(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(eta*xt(3*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+3))+(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(pi_O*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(eta*xt(3*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+4))+(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((lamGenital(b,:)').*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(eta*xt(3*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+5))+(vaccin_perd*xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(pi_G*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(3*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
% Waned immune protection following booster vaccination
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)=(eta*xt(4*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+1))+(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamOral(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))-((lamGenital(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)=(eta*xt(4*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+2))+(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))+((lamOral(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(gama_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)=(eta*xt(4*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+3))+(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))+(gama_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2))-(pi_O*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)=(eta*xt(4*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+4))+(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))+((lamGenital(b,:)').*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1))+(pi_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(gama_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4));
dx(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)=(eta*xt(4*Nc*Nr*Nb+(b-2)*Nc*Nr+(i-1)*Nc+5))+(vaccin_perd*xt(2*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))+(gama_G.*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4))-(pi_G*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(Mortality_rate(:,b).*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5))-(eta*xt(4*Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5));
dVPS(b)=sum(vaccin_Rate(b)*(xt((b-1)*Nc*Nr+(i-1)*Nc+1)+xt((b-1)*Nc*Nr+(i-1)*Nc+2)+xt((b-1)*Nc*Nr+(i-1)*Nc+3)+xt((b-1)*Nc*Nr+(i-1)*Nc+4)+xt((b-1)*Nc*Nr+(i-1)*Nc+5)));% vaccine primari series
dVb(b)= sum(vaccin_Rateb(b)*(xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+1)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+2)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+3)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+4)+xt(Nc*Nr*Nb+(b-1)*Nc*Nr+(i-1)*Nc+5)));
dx(5*Nc*Nr*Nb+b)=dVPS(b)+(eta*xt(5*Nc*Nr*Nb+(b-1)))-(eta*xt(5*Nc*Nr*Nb+b))-(Mortality_rate(:,b).*dx(5*Nc*Nr*Nb+b));
end
VPS=sum(dVPS);
Vb=sum(dVb);
dydt=dx;
%    


