%% --------------------------------------------------------------------- %%
%  Vaccine Coverage Visualization Across Four Scenarios
%  This script loads vaccine coverage data for four vaccination scenarios,
%  then plots vaccine and effective coverage trajectories over time.
% ---------------------------------------------------------------------- %%
clear all
close all 
clc




load('Scenario1.mat')
VaccineCovergeS1=VaccineCoverage;
EffectiveVaccinCovergeS1=EffectiveCoverage;
load('Scenario2.mat')
VaccineCovergeS2=VaccineCoverage;
EffectiveVaccinCovergeS2=EffectiveCoverage;
EffectiveVaccinCovergeS2_10_14=vaccineCovearage10_14;
load('Scenario3.mat')
VaccineCovergeS3=VaccineCoverage;
EffectiveVaccinCovergeS3=EffectiveCoverage;
EffectiveVaccinCovergeS3_10_14=vaccineCovearage10_14;
load('Scenario4.mat')
VaccineCovergeS4=VaccineCoverage;
EffectiveVaccinCovergeS4=EffectiveCoverage;

%% ---------------------------- Time Settings ---------------------------- %%
t0 = 1750;   % start year of model
tf = 2100;   % end year of model
dt = 0.5;    % time step (years)
t = t0:dt:tf+dt;

%% ---------------------------- Plot Settings ---------------------------- %%
figure

% ====================== Scenario 1 ===================================== %

subplot(2,2,1)
hold on
h1=plot(t((1950-t0+0.5)*2:end),VaccineCovergeS1((1950-t0+0.5)*2:end),'k--','LineWidth',2.5)
h2=plot(t((1950-t0+0.5)*2:end),EffectiveVaccinCovergeS1((1950-t0+0.5)*2:end),'b-','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:(2030-t0+0.5)*2),EffectiveVaccinCovergeS1((1950-t0+0.5)*2:(2030-t0+0.5)*2),'k-','LineWidth',2.5)


%yline(80,'r--')
xticks(1950:10:2100)
ylabel({'Coverage in the total U.S. population (%)'},'FontSize', 8)
xlim([1970,2100])
ylim([0,100])
xline(2030,'k--','LineWidth', 2)
legend('Vaccine coverage','Effective vaccine coverage','Orientation','horizontal')
title({'Scenario 1, infant vaccination with';'lifelong protection'},'FontSize', 8)
xlabel('Year','FontSize', 8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
xlim([2020,2100]);
VaccineCoverge_S1=VaccineCovergeS1(([2050,2075,2100]-t0+0.5)*2)
set(gca, 'FontSize', 8)

% ====================== Scenario 2 ===================================== %


subplot(2,2,2)
hold on
plot(t((1950-t0+0.5)*2:end),VaccineCovergeS2((1950-t0+0.5)*2:end),'k--','LineWidth',2.5)
plot(t((1950-t0+0.5)*2:end),EffectiveVaccinCovergeS2((1950-t0+0.5)*2:end),'b-','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:(2030-t0+0.5)*2),EffectiveVaccinCovergeS2((1950-t0+0.5)*2:(2030-t0+0.5)*2),'k-','LineWidth',2.5)

xticks(1950:10:2100);
ylim([0,100])
ylabel({'Coverage in the total U.S. population (%)'},'FontSize', 8)
xlim([1970,2100])
ylim([0,100])
xline(2030,'k--','LineWidth', 2)
legend('Vaccine coverage','Effective vaccine coverage')
title({'Scenario 2, infant and adolescent';'catch-up vaccination with';'lifelong protection'},'FontSize', 8)
xlabel('Year','FontSize', 8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
xlim([2020,2100])
VaccineCoverge_S2=VaccineCovergeS2(([2050,2075,2100]-t0+0.5)*2)
set(gca, 'FontSize', 8)

% ====================== Scenario 3 ===================================== %


subplot(2,2,3)
hold on
plot(t((1950-t0+0.5)*2:end),VaccineCovergeS3((1950-t0+0.5)*2:end),'k--','LineWidth',2.5)
plot(t((1950-t0+0.5)*2:end),EffectiveVaccinCovergeS3((1950-t0+0.5)*2:end),'b-','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:(2030-t0+0.5)*2),EffectiveVaccinCovergeS3((1950-t0+0.5)*2:(2030-t0+0.5)*2),'k-','LineWidth',2.5)

xlim([2020,2100])
xticks(1950:10:2100)
ylabel({'Coverage in the total U.S. population (%)'},'FontSize', 8)
ylim([0,100])
xline(2030,'k--','LineWidth', 2)
legend('Vaccine coverage','Effective vaccine coverage')
title({'Scenario 3, infant, adolescent catch-up,';'and adolescent booster vaccination';'with 15-year protection'},'FontSize', 8)
xlabel('Year','FontSize', 8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
VaccineCoverge_S3=VaccineCovergeS3(([2050,2075,2100]-t0+0.5)*2)
set(gca, 'FontSize', 8)
% ====================== Scenario 4 ===================================== %

subplot(2,2,4)
hold on
plot(t((1950-t0+0.5)*2:end),VaccineCovergeS4((1950-t0+0.5)*2:end),'k--','LineWidth',2.5)
plot(t((1950-t0+0.5)*2:end),EffectiveVaccinCovergeS4((1950-t0+0.5)*2:end),'b-','LineWidth',1.5)
plot(t((1950-t0+0.5)*2:(2030-t0+0.5)*2),EffectiveVaccinCovergeS4((1950-t0+0.5)*2:(2030-t0+0.5)*2),'k-','LineWidth',2.5)

xticks(1950:10:2100)
ylabel({'Coverage in the total U.S. population (%)'},'FontSize', 8)
xlim([2020,2100])
ylim([0,100])
xline(2030,'k--','LineWidth', 2);
legend('Vaccine coverage','Effective vaccine coverage')
title({'Scenario 4, infant vaccination with';' 15-year protection'},'FontSize', 8)
xlabel('Year','FontSize', 8)
txt = 'Vaccine introduction in 2030';
ts=text(2027.5,5,txt,'FontSize',8);
ts.Rotation = 90;
xlim([2020,2100]);
VaccineCoverge_S4=VaccineCovergeS4(([2050,2075,2100]-t0+0.5)*2)
set(gca, 'FontSize', 8)