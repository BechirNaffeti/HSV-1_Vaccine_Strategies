%% ===================================================================== %%
%   HSV-1 Vaccination Scenario1 Analysis
%   This script compares model outputs (prevalence, incidence, vaccination)
%   between no-vaccine and different vaccine efficacy (VE) scenarios:
%   VE = 50%, 70%, 90%.
%   It computes relative reductions and cumulative infection averted.
clear all
close all 
clc


%% --------------------------------------------------------------------- %%
% Load baseline scenario: No vaccination
% ---------------------------------------------------------------------- %%
load('Withoutvaccin.mat')
% Extract and rename relevant model outputs
PrevalenceTotalWV=PrevalenceTotal;
IncidenceGenitalyearWV=IncidenceGenitalyear;
IncidenceOralyearWV=IncidenceOralyear;
IncidenceGenitalrateWV=IncidenceGenitalrate;
IncidenceOralrateWV=IncidenceOralrate;
EffectiveVaccinaBirthWV=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesWV=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostWV=EffectiveVaccineBoostyear;
% Total infections and total vaccinated population
TotalinfectedWV=IncidenceGenitalyearWV+IncidenceOralyearWV;     
TotalvaccieWV=EffectiveVaccinaBirthWV+EffectiveVaccinePrimarySeriesWV+EffectiveVaccineBoostWV;


%% --------------------------------------------------------------------- %%
% Load vaccination scenario: VE = 50%
% ---------------------------------------------------------------------- %%
load('Scenario1VE50.mat')
PrevalenceTotalVE50=PrevalenceTotal;
IncidenceGenitalyearVE50=IncidenceGenitalyear;
IncidenceOralyearVE50=IncidenceOralyear;
IncidenceGenitalrateVE50=IncidenceGenitalrate;
IncidenceOralrateVE50=IncidenceOralrate;
EffectiveVaccinaBirthVE50=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50=EffectiveVaccineBoostyear;
% Total infections and vaccinated population (VE = 50%)
TotalinfectedVE50=IncidenceGenitalyearVE50+IncidenceOralyearVE50;   
TotalvaccieVE50=EffectiveVaccinaBirthVE50+EffectiveVaccinePrimarySeriesVE50+EffectiveVaccineBoostVE50;
%% --------------------------------------------------------------------- %%
% Load vaccination scenario: VE = 70%
% ---------------------------------------------------------------------- %%
load('Scenario1VE70.mat')
PrevalenceTotalVE70=PrevalenceTotal;
IncidenceGenitalyearVE70=IncidenceGenitalyear;
IncidenceOralyearVE70=IncidenceOralyear;
IncidenceGenitalrateVE70=IncidenceGenitalrate;
IncidenceOralrateVE70=IncidenceOralrate;
EffectiveVaccinaBirthVE70=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70=EffectiveVaccineBoostyear;
% Total infections and vaccinated population (VE = 70%)
TotalinfectedVE70=IncidenceGenitalyearVE70+IncidenceOralyearVE70;   
TotalvaccieVE70=EffectiveVaccinaBirthVE70+EffectiveVaccinePrimarySeriesVE70+EffectiveVaccineBoostVE70;

%% --------------------------------------------------------------------- %%
% Load vaccination scenario: VE = 90%
% ---------------------------------------------------------------------- %%
load('Scenario1VE90.mat')
PrevalenceTotalVE90=PrevalenceTotal;
IncidenceGenitalyearVE90=IncidenceGenitalyear;
IncidenceOralyearVE90=IncidenceOralyear;
IncidenceGenitalrateVE90=IncidenceGenitalrate;
IncidenceOralrateVE90=IncidenceOralrate;
EffectiveVaccinaBirthVE90=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90=EffectiveVaccineBoostyear;
% Total infections and vaccinated population (VE = 90%)
TotalinfectedVE90=IncidenceGenitalyearVE90+IncidenceOralyearVE90;   
TotalvaccieVE90=EffectiveVaccinaBirthVE90+EffectiveVaccinePrimarySeriesVE90+EffectiveVaccineBoostVE90;


%% --------------------------------------------------------------------- %%
% Simulation time settings
% ---------------------------------------------------------------------- %%
t0 = 1750;    % Start year of the model
tf = 2100;    % End year
dt = 0.5;     % Time step (years)
years = [2050 2075 2100];  % Evaluation years for reporting reductions


%% --------------------------------------------------------------------- %%
% Calculate percentage reduction in prevalence,incidence and incidence rate for each VE
% scenario relative to no vaccination (WV = Without Vaccine)
% ---------------------------------------------------------------------- %%
for j=1:3 
   % ----- Prevalence reduction -----
   reductionPrevTotal50(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE50((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal70(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE70((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   reductionPrevTotal90(j)= (PrevalenceTotalWV((years(j)-t0+0.5)*2)-PrevalenceTotalVE90((years(j)-t0+0.5)*2))./PrevalenceTotalWV((years(j)-t0+0.5)*2);
   
   % ----- Oral incidence rate reduction -----
   reductionIncidencerateOral50(j)=(IncidenceOralrateWV((years(j)-t0+1))-IncidenceOralrateVE50((years(j)-t0+1)))./IncidenceOralrateWV((years(j)-t0+1));
   reductionIncidencerateOral70(j)=(IncidenceOralrateWV((years(j)-t0+1))-IncidenceOralrateVE70((years(j)-t0+1)))./IncidenceOralrateWV((years(j)-t0+1));
   reductionIncidencerateOral90(j)=(IncidenceOralrateWV((years(j)-t0+1))-IncidenceOralrateVE90((years(j)-t0+1)))./IncidenceOralrateWV((years(j)-t0+1));

  % ----- Oral incidence reduction -----
   reductionNewcasesOral50(j)=(IncidenceOralyearWV((years(j)-t0+1))-IncidenceOralyearVE50((years(j)-t0+1)))./IncidenceOralyearWV((years(j)-t0+1));
   reductionNewcasesOral70(j)=(IncidenceOralyearWV((years(j)-t0+1))-IncidenceOralyearVE70((years(j)-t0+1)))./IncidenceOralyearWV((years(j)-t0+1));
   reductionNewcasesOral90(j)=(IncidenceOralyearWV((years(j)-t0+1))-IncidenceOralyearVE90(years(j)-t0+1))./IncidenceOralyearWV(years(j)-t0+1);
  
  % ----- Genital incidence rate reduction -----
   reductionIncidencerateGenital50(j)=(IncidenceGenitalrateWV((years(j)-t0+1))-IncidenceGenitalrateVE50(years(j)-t0+1))./IncidenceGenitalrateWV((years(j)-t0+1));
   reductionIncidencerateGenital70(j)=(IncidenceGenitalrateWV((years(j)-t0+1))-IncidenceGenitalrateVE70(years(j)-t0+1))./IncidenceGenitalrateWV((years(j)-t0+1));
   reductionIncidencerateGenital90(j)=(IncidenceGenitalrateWV((years(j)-t0+1))-IncidenceGenitalrateVE90(years(j)-t0+1))./IncidenceGenitalrateWV((years(j)-t0+1));
  
  % ----- Genital incidence rate reduction -----
   reductionNewcasesGenital50(j)=(IncidenceGenitalyearWV((years(j)-t0+1))-IncidenceGenitalyearVE50(years(j)-t0+1))./IncidenceGenitalyearWV((years(j)-t0+1));
   reductionNewcasesGenital70(j)=(IncidenceGenitalyearWV((years(j)-t0+1))-IncidenceGenitalyearVE70(years(j)-t0+1))./IncidenceGenitalyearWV((years(j)-t0+1));
   reductionNewcasesGenital90(j)=(IncidenceGenitalyearWV((years(j)-t0+1))-IncidenceGenitalyearVE90(years(j)-t0+1))./IncidenceGenitalyearWV((years(j)-t0+1));

   
end




%% --------------------------------------------------------------------- %%
% Display all reduction results after loop
% ---------------------------------------------------------------------- %%
fprintf('\n================ VACCINE IMPACT SUMMARY ================\n');
fprintf('Comparison at years: %d, %d, %d\n\n', years(1), years(2), years(3));

fprintf('--- Prevalence Reduction (%%) ---\n');
disp(array2table([reductionPrevTotal50'*100, reductionPrevTotal70'*100, reductionPrevTotal90'*100], ...
    'VariableNames', {'VE50', 'VE70', 'VE90'}, 'RowNames', cellstr(string(years))));

fprintf('--- Oral Incidence Rate Reduction (%%) ---\n');
disp(array2table([reductionIncidencerateOral50'*100, reductionIncidencerateOral70'*100, reductionIncidencerateOral90'*100], ...
    'VariableNames', {'VE50', 'VE70', 'VE90'}, 'RowNames', cellstr(string(years))));

fprintf('--- Oral New Cases Reduction (%%) ---\n');
disp(array2table([reductionNewcasesOral50'*100, reductionNewcasesOral70'*100, reductionNewcasesOral90'*100], ...
    'VariableNames', {'VE50', 'VE70', 'VE90'}, 'RowNames', cellstr(string(years))));

fprintf('--- Genital Incidence Rate Reduction (%%) ---\n');
disp(array2table([reductionIncidencerateGenital50'*100, reductionIncidencerateGenital70'*100, reductionIncidencerateGenital90'*100], ...
    'VariableNames', {'VE50', 'VE70', 'VE90'}, 'RowNames', cellstr(string(years))));

fprintf('--- Genital New Cases Reduction (%%) ---\n');
disp(array2table([reductionNewcasesGenital50'*100, reductionNewcasesGenital70'*100, reductionNewcasesGenital90'*100], ...
    'VariableNames', {'VE50', 'VE70', 'VE90'}, 'RowNames', cellstr(string(years))));

fprintf('========================================================\n');

%% --------------------------------------------------------------------- %%
% Compute cumulative infections averted and vaccination ratios (2030�2100)
% Avert ratio = total vaccinated / total infections averted
% ---------------------------------------------------------------------- %%
years1=2035:2100;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(years1)
    % --- VE = 50% ---
    CumulativeAvertInfection50(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination50(j)=sum(TotalvaccieVE50(2030-t0+1:years1(j)-t0+1));
    Avert50(j)=CumulativeVaccination50(j)/ CumulativeAvertInfection50(j);
    
    % --- VE = 70% ---
    CumulativeAvertInfection70(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination70(j)=sum(TotalvaccieVE70(2030-t0+1:years1(j)-t0+1));
    Avert70(j)=CumulativeVaccination70(j)/ CumulativeAvertInfection70(j);
    
    % --- VE = 90% ---
    CumulativeAvertInfection90(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90(2030-t0+1:years1(j)-t0+1));
    CumulativeVaccination90(j)=sum(TotalvaccieVE90(2030-t0+1:years1(j)-t0+1));
    Avert90(j)=CumulativeVaccination90(j)/ CumulativeAvertInfection90(j);
    
    
    
    
    
end

%% --------------------------------------------------------------------- %%
% Display cumulative results for years 2040:10:2100 (rounded to 1 decimal)
% ---------------------------------------------------------------------- %%
fprintf('\n================ CUMULATIVE IMPACT (2040�2100, every 10 years) ================\n');

% Select only the desired years (2040:10:2100)
selectYears = 2040:10:2100;
[~, idx] = ismember(selectYears, years1);

% Round all results to 1 decimal
CumInf  = round([CumulativeAvertInfection50(:), CumulativeAvertInfection70(:), CumulativeAvertInfection90(:)], 1);
CumVacc = round([CumulativeVaccination50(:),   CumulativeVaccination70(:),   CumulativeVaccination90(:)],   1);
Avert   = round([Avert50(:),                   Avert70(:),                   Avert90(:)],                   1);

% Extract only the selected rows
CumInf  = CumInf(idx, :);
CumVacc = CumVacc(idx, :);
Avert   = Avert(idx, :);
rowNames = cellstr(string(selectYears));

% Display tables
fprintf('--- Cumulative Infections Averted ---\n');
disp(array2table(CumInf,  'VariableNames', {'VE50','VE70','VE90'}, 'RowNames', rowNames));

fprintf('--- Cumulative Vaccinations Administered ---\n');
disp(array2table(CumVacc, 'VariableNames', {'VE50','VE70','VE90'}, 'RowNames', rowNames));

fprintf('--- Vaccinations per Infection Averted (Avert) ---\n');
disp(array2table(Avert,   'VariableNames', {'VE50','VE70','VE90'}, 'RowNames', rowNames));

fprintf('==========================================================================\n');


%% Save solution
save('S1Averted.mat','CumulativeAvertInfection50','CumulativeAvertInfection70','CumulativeAvertInfection90')
%save('TotalinfectedWV')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,
subplot(2,2,1)
hold on

h2=plot(t(1:2:end),1000*IncidenceOralrateVE50,'b-','LineWidth',1.5);
h3=plot(t(1:2:end),1000*IncidenceOralrateVE70,'g-','LineWidth',1.5);
h4=plot(t(1:2:end),1000*IncidenceOralrateVE90,'r-','LineWidth',1.5);
h1=plot(t(1:2:end),1000*IncidenceOralrateWV,'k-','LineWidth',1.5);

ylabel({'Oral HSV-1 incidence rate';'(per 1,000 person-years)'},'FontSize',8)
xlabel('Year','FontSize',8)
xline(2030,'k--','LineWidth', 2);
xlim([2020,2100])
xticks(2020:20:2100)
ylim([0,20])
txt = 'Vaccine introduction in 2030';
ts=text(2027,1,txt,'FontSize',8);
ts.Rotation = 90;
legend([h1 h2 h3 h4], ...
       'No vaccination', ...
       'VE_s=50%', ...
       'VE_s=70%', ...
       'VE_s=90%',...
        'Orientation','horizontal');
title('A','FontSize',9)
set(gca,'FontSize',8)


subplot(2,2,2)
hold on
h2=plot(t(1:2:end),1000*IncidenceGenitalrateVE50,'b-','LineWidth',1.5);
h3=plot(t(1:2:end),1000*IncidenceGenitalrateVE70,'g-','LineWidth',1.5);
h4=plot(t(1:2:end),1000*IncidenceGenitalrateVE90,'r-','LineWidth',1.5);
h1=plot(t(1:2:end),1000*IncidenceGenitalrateWV,'k-','LineWidth',1.5);
ylabel({'Genital HSV-1 incidence rate';'(per 1,000 person-years)'},'FontSize',8)
xlim([2020,2100])
ylim([0,4])
xline(2030,'k--','LineWidth', 2);
xlabel('Year','FontSize',8)
xticks(2020:20:2100)
txt = 'Vaccine introduction in 2030';
ts=text(2027,0.2,txt,'FontSize',8);
ts.Rotation = 90;
title('B','FontSize',9)
set(gca,'FontSize',8)

subplot(2,2,3)
hold on
h2=plot(t(1:2:end),IncidenceOralyearVE50./1e6,'b-','LineWidth',1.5);
h3=plot(t(1:2:end),IncidenceOralyearVE70./1e6,'g-','LineWidth',1.5);
h4=plot(t(1:2:end),IncidenceOralyearVE90./1e6,'r-','LineWidth',1.5);
h1=plot(t(1:2:end),IncidenceOralyearWV./1e6,'k-','LineWidth',1.5);
ylabel({'Annual number of new oral HSV-1'; 'infections (millions)'})
xlim([2020,2100])
xticks(2020:20:2100)
ylim([0,3.5])
xline(2030,'k--','LineWidth', 2);
%grid on
xlabel('Year','FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027,0.16,txt,'FontSize',8);
ts.Rotation = 90;
title('C','FontSize',9);
set(gca,'FontSize',8)
subplot(2,2,4)
hold on
h2=plot(t(1:2:end),IncidenceGenitalyearVE50./1e6,'b-','LineWidth',1.5);
h3=plot(t(1:2:end),IncidenceGenitalyearVE70./1e6,'g-','LineWidth',1.5);
h4=plot(t(1:2:end),IncidenceGenitalyearVE90./1e6,'r-','LineWidth',1.5);
h1=plot(t(1:2:end),IncidenceGenitalyearWV./1e6,'k-','LineWidth',1.5);
%legend('No vaccination','VE_s^O=VE_s^G=50%','VE_s^O=VE_s^G=70%','VE_s^O=VE_s^G=90%')
ylabel({'Annual number of new genital HSV-1'; 'infections (millions)'})
xlim([2020,2100])
xticks(2020:20:2100)
xline(2030,'k--','LineWidth', 2);
ylim([0,0.7])
%grid on
xlabel('Year','FontSize',8)
txt = 'Vaccine introduction in 2030';
ts=text(2027,0.04,txt,'FontSize',8);
ts.Rotation = 90;
title('D','FontSize',9)
set(gca,'FontSize',8)