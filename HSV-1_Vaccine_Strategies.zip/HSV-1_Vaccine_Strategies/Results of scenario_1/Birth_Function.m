function y = Birth_Function(t,a0,a1,a2)
y=a0.*exp(-((t-(a1))./(a2)).^2);
end


