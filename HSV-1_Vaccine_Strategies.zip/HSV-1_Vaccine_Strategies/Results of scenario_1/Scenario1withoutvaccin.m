clear all
close all 
clc
%% Fixed paramters
Nc=5;% Number of compartments within each vaccination status
%parameters related to risk
Nr=3;%number of risk groups
%parameters related to age groups
Nb=20;%age interval of five years
% parameters related to assortativeness
e_AO=0.75; %Degree of assortativeness in age-group mixing for oral contacts.. 
e_ROS=0.3; %Degree of assortativeness in risk-group mixing for oralsex contacts.
e_RSI=0.3;  %Degree of assortativeness in risk-group mixing for sexual intercourse contacts.
e_AOS=0.7;  %Degree of assortativeness in age-group mixing for oralsex contacts.
e_ASI=0.7; % %Degree of assortativeness in age-group mixing for  sexual intercourse contacts.


% Transmission Probabilities
Prob_Ioral=0.01; %  Probability of HSV-1 transmission per oral sex act
Prob_Igenital=0.01; % Probability of HSV-1 transmission per vaginal intercourse act
% % Frequency of Coital Acts 
% Average weekly frequency of coital acts by age group (ages 15�65, roughly) 
FrequencyOfCoitalActA=[3.90 3.50 3.20 2.90 2.50 2.20 1.90 1.50 1.20 0.87]; 
% Initialize full vector for all age groups (size 20, as per model structure)
FrequencyOfCoitalAct=zeros(20,1);
% Assign yearly frequency (convert from weekly rates � 52 weeks)
FrequencyOfCoitalAct(4:13)=365.*FrequencyOfCoitalActA/7; 
% % Transmission probabilities per partnership
% HSV-1 transmission probability per partnership via oral sex with an
% infectious oral partner.
TranProb_O_OS= 1-((1-Prob_Ioral).^FrequencyOfCoitalAct)   ;
% HSV-1 transmission probability per partnership via oral sex with a
% infectious genital partner.
TranProb_G_OS=1-((1-Prob_Ioral).^FrequencyOfCoitalAct)   ;
% HSV-1 transmission probability per partnership via genital sex 
TranProb_G_SI=1-((1-Prob_Igenital).^FrequencyOfCoitalAct); 


% % Transition rates
Xi_oral=0.137;% Oral HSV-1 shedding frequency 
Xi_genital=0.0151;% Genetic HSV-1 shedding frequency
chi_oral=16.2; %  Frequency of oral HSV-1 reactivations
chi_genital=0.7;%  Frequency of genital HSV-1 reactivations
pi_O= 365*(1/(((1-Xi_oral)/chi_oral)*365)); % 1/pi_O = mean latency between oral reactivations
pi_G=365*(1/(((1-Xi_genital)/chi_genital)*365)); % 1/pi_G = mean latency between genital reactivations
gama_O= 365*(1/(((Xi_oral)/chi_oral)*365)); %  1/gama_O = mean duration of an oral reactivations
gama_G=365*(1/(((Xi_genital)/chi_genital)*365));%  1/gama_G= mean duration of a genital reactivations

eta=1/5;% Transition rate between age groups.
theta=4.5;% Exponent parameter for the power-law function
% Power-law function 
Risk=1:3;
Pwlaw=Risk.^theta;
f_S_G=0.26; % Fraction of genital HSV-1 infections that are symptomatic

% psi: function describing age-specific variation in sexual activity
a   = 1:Nb;  % Age group index (1 to Nb)
Psi = 0.913 .* exp(-((a - 8.48) ./ 8.317) .^ 2);  % Age-dependent function
Psi(1:3) = zeros(1,3);  % Set Psi to zero for the first three age groups
% C_SI: constant scaling factor determined by the average risk of exposure via sexual intercourse
C_SI = 0.0102;  
%% Vaccination Parameters
vaccin_perd      = 0;    % Vaccine waning rate (per year) � 0 means lifelong immunity
VE               = 0;  % Vaccine efficacy (fractional reduction in susceptibility)

vaccinFraction1  = 0;    % Vaccination rate for catch-up vaccination
vaccinFraction2  = 0;    % Vaccination rate for booster vaccination
Vbirth           = 0;  % Vaccination coverage at birth (neonatal vaccination rate) 
%% Import demographic parameters.
values_1 = [0.0193524780680780,0.191983841953055*10^4,202.877050848782,1.50364017711900*10,0.712882576229875,0.514853119211157,0.176083059120317*10^4,162.966550317040];
a0 = values_1(1);
a1 = values_1(2);
a2 = values_1(3);
c0 = values_1(6);
c1 = values_1(7);
c2 = values_1(8);
c4 = values_1(4);
c3 = values_1(5);
Optimal=[a0 a1 a2 c0 c1 c2 c3 c4];
%% Create Initial solution
epsilon = 10^-6;
data_USA = readtable('Population Size Zoom.xlsx', 'ReadVariableNames', false);
year = str2double(table2array(data_USA(1:70, 1)));
numericData_total = table2array(data_USA(1:70, 23));
data_USA_numeric = table2array(data_USA(1:21, 2:21));
data_USA_numeric = str2double(data_USA_numeric);
B = data_USA_numeric(1,:);
Population=B;
RiskGroupPopulationFactors=[0.0794,0.6883,0.2304];
N_0=RiskGroupPopulationFactors.*(Population)';
Init_prevOral=0.3;
Init_prevGenital=0.15;
I_Oral=Init_prevOral.*N_0;
A_Oral=Init_prevOral.*N_0;
I_Genital= zeros(Nb,Nr);
I_Genital(4:20,:)=Init_prevGenital.*N_0(4:20,:);
A_Genital= zeros(Nb,Nr);
A_Genital(4:20,:)=Init_prevGenital.*N_0(4:20,:);
S0=N_0-(I_Oral+A_Oral+I_Genital+A_Genital);
S0=S0;
x0=[];
for b=1:Nb
    for i=1:Nr
        x0=[x0, S0(b,i),I_Oral(b,i),A_Oral(b,i),I_Genital(b,i),A_Genital(b,i)];
    end
end
SolInitial1=x0+epsilon;
SolInitial1=[SolInitial1,zeros(1,4*length(x0)),zeros(1,Nb)];
%% Optimal Data-Fit Parameters
% Vector z contains the optimal parameter values obtained from model fitting
% (Last fitting results: 11/04/2018)
z=[0.249999970452327;24.9999982481145;1.81623881363446;0.199499999744568;0.00340000001604559]; %%Fitting Last Result (11/04/2018)
Xi_t=z(4)*1e4;
Xi_D=z(2);
Z=z(3);
Rou0=z(1);
C_OS=z(5);
%% Run Model
t0   = 1750;   % Start year
tf   = 2100;   % End year
dt   = 0.5;    % Time step (years)
tspan = t0:dt:tf+dt;  % Simulation time grid
[t,y]=ode15s(@ModelHSV1_vaccin, tspan,SolInitial1,[],Nc,Nr,Nb,vaccin_perd,vaccinFraction1,vaccinFraction2,Vbirth,VE,e_AO,e_ROS,e_RSI,e_AOS,e_ASI,Optimal,Pwlaw,eta,pi_O,pi_G,gama_O,gama_G,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI,Xi_t, Xi_D,Z,Rou0,C_OS,C_SI,Psi);
%% Results
S1=y(:,1:Nc:Nc*Nr*Nb);
IO1=y(:,2:Nc:Nc*Nr*Nb);
AO1=y(:,3:Nc:Nc*Nr*Nb);
IG1=y(:,4:Nc:Nc*Nr*Nb);
AG1=y(:,5:Nc:Nc*Nr*Nb);
V1=y(:,Nc*Nr*Nb+1:Nc:2*Nc*Nr*Nb);
IvO1=y(:,Nc*Nr*Nb+2:Nc:2*Nc*Nr*Nb);
AvO1=y(:,Nc*Nr*Nb+3:Nc:2*Nc*Nr*Nb);
IvG1=y(:,Nc*Nr*Nb+4:Nc:2*Nc*Nr*Nb);
AvG1=y(:,Nc*Nr*Nb+5:Nc:2*Nc*Nr*Nb);
Vb1=y(:,2*Nc*Nr*Nb+1:Nc:3*Nc*Nr*Nb);
IvbO1=y(:,2*Nc*Nr*Nb+2:Nc:3*Nc*Nr*Nb);
AvbO1=y(:,2*Nc*Nr*Nb+3:Nc:3*Nc*Nr*Nb);
IvbG1=y(:,2*Nc*Nr*Nb+4:Nc:3*Nc*Nr*Nb);
AvbG1=y(:,2*Nc*Nr*Nb+5:Nc:3*Nc*Nr*Nb);
Swp1=y(:,3*Nc*Nr*Nb+1:Nc:4*Nc*Nr*Nb);
IwpO1=y(:,3*Nc*Nr*Nb+2:Nc:4*Nc*Nr*Nb);
AwpO1=y(:,3*Nc*Nr*Nb+3:Nc:4*Nc*Nr*Nb);
IwpG1=y(:,3*Nc*Nr*Nb+4:Nc:4*Nc*Nr*Nb);
AwpG1=y(:,3*Nc*Nr*Nb+5:Nc:4*Nc*Nr*Nb);
Swb1=y(:,4*Nc*Nr*Nb+1:Nc:5*Nc*Nr*Nb);
IwbO1=y(:,4*Nc*Nr*Nb+2:Nc:5*Nc*Nr*Nb);
AwbO1=y(:,4*Nc*Nr*Nb+3:Nc:5*Nc*Nr*Nb);
IwbG1=y(:,4*Nc*Nr*Nb+4:Nc:5*Nc*Nr*Nb);
AwbG1=y(:,4*Nc*Nr*Nb+5:Nc:5*Nc*Nr*Nb);
PeopleVaccinated=y(:,5*Nc*Nr*Nb+1:5*Nc*Nr*Nb+Nb);
for b=1:Nb
    S(:,:,b)=S1(:,(b-1)*Nr+(1:3));
    IOral(:,:,b)=IO1(:,(b-1)*Nr+(1:3));
    AOral(:,:,b)=AO1(:,(b-1)*Nr+(1:3));
    IGenital(:,:,b)=IG1(:,(b-1)*Nr+(1:3));
    AGenital(:,:,b)=AG1(:,(b-1)*Nr+(1:3)); 
    V(:,:,b)=V1(:,(b-1)*Nr+(1:3));
    IvOral(:,:,b)=IvO1(:,(b-1)*Nr+(1:3));
    AvOral(:,:,b)=AvO1(:,(b-1)*Nr+(1:3));
    IvGenital(:,:,b)=IvG1(:,(b-1)*Nr+(1:3));
    AvGenital(:,:,b)=AvG1(:,(b-1)*Nr+(1:3)); 
    Vb(:,:,b)=Vb1(:,(b-1)*Nr+(1:3));
    IvbOral(:,:,b)=IvbO1(:,(b-1)*Nr+(1:3));
    AvbOral(:,:,b)=AvbO1(:,(b-1)*Nr+(1:3));
    IvbGenital(:,:,b)=IvbG1(:,(b-1)*Nr+(1:3));
    AvbGenital(:,:,b)=AvbG1(:,(b-1)*Nr+(1:3)); 
    Swp(:,:,b)=Swp1(:,(b-1)*Nr+(1:3));
    IwpOral(:,:,b)=IwpO1(:,(b-1)*Nr+(1:3));
    AwpOral(:,:,b)=AwpO1(:,(b-1)*Nr+(1:3));
    IwpGenital(:,:,b)=IwpG1(:,(b-1)*Nr+(1:3));
    AwpGenital(:,:,b)=AwpG1(:,(b-1)*Nr+(1:3)); 
    Swb(:,:,b)=Swb1(:,(b-1)*Nr+(1:3));
    IwbOral(:,:,b)=IwbO1(:,(b-1)*Nr+(1:3));
    AwbOral(:,:,b)=AwbO1(:,(b-1)*Nr+(1:3));
    IwbGenital(:,:,b)=IwbG1(:,(b-1)*Nr+(1:3));
    AwbGenital(:,:,b)=AwbG1(:,(b-1)*Nr+(1:3)); 
end

%% Calculations of Prevalence in total population
InfectedUnvaccinated=sum(sum(IOral,2)+sum(AOral,2)+sum(IGenital,2)+sum(AGenital,2),3);
InfectedPrimaryVaccination=sum(sum(IvOral,2)+sum(AvOral,2)+sum(IvGenital,2)+sum(AvGenital,2),3);
InfectedBoostVaccinated=sum(sum(IvbOral,2)+sum(AvbOral,2)+sum(IvbGenital,2)+sum(AvbGenital,2),3);
InfectedWanningPrimary=sum(sum(IwpOral,2)+sum(AwpOral,2)+sum(IwpGenital,2)+sum(AwpGenital,2),3);
InfectedWanningBoost=sum(sum(IwbOral,2)+sum(AwbOral,2)+sum(IwbGenital,2)+sum(AwbGenital,2),3);
PrevalenceTotal=100*(InfectedUnvaccinated+InfectedPrimaryVaccination+InfectedBoostVaccinated+InfectedWanningPrimary+InfectedWanningBoost)./sum(y(:,1:5*Nc*Nr*Nb),2);
PopulationTotal_Age=squeeze(sum(S,2)+sum(IOral,2)+sum(AOral,2)+sum(IGenital,2)+sum(AGenital,2));




%% Calculation of the vaccination coverages
% Compute the total number of effectively vaccinated individuals 
% (i.e., people who are alive and possess vaccine-induced immunity),
% including all vaccinated groups (V and Vb) as well as individuals 
% who became infected after receiving either primary or booster vaccination.
EffectiveVaccinated=sum(sum(V,2)+sum(Vb,2),3)+InfectedPrimaryVaccination+InfectedBoostVaccinated;
% Calculate the effective vaccination coverage (percentage)
% as the proportion of effectively vaccinated individuals 
% relative to the total living population.
EffectiveCoverage=100*EffectiveVaccinated./sum(y(:,1:5*Nc*Nr*Nb),2);
% Calculate the overall vaccination coverage (percentage) 
% as the proportion of all vaccinated individual
% relative to the total living population.
VaccineCoverage=100*(sum(PeopleVaccinated,2)./sum(y(:,1:5*Nc*Nr*Nb),2));
%% Calculation of the incidence
TT=length(t);
    for i=1:TT 
      
       Susceptible(:,:,i)=reshape(S(i,:,:),3,20)';  % Susceptible, unvaccinated individuals
       SusceptiblePS(:,:,i)=reshape(V(i,:,:),3,20)'; % Susceptible individuals with primary-series vaccination
       SusceptibleB(:,:,i)=reshape(Vb(i,:,:),3,20)';  % Susceptible individuals with booster vaccination
       SusceptibleWPS(:,:,i)=reshape(Swp(i,:,:),3,20)';% Susceptible individuals with waned immunity after primary-series vaccination
       SusceptibleWB(:,:,i)=reshape(Swb(i,:,:),3,20)'; % Susceptible individuals with waned immunity after booster vaccination
       Xt=y(i,:);
       % Evaluate model to get forces of infection (lam..) and �effective vaccination� outputs
       [dydt,lamOO,lamGO,lamOG,lamGG,EffvBirth,EffvPS,  EffVboost]=ModelHSV1_vaccin(t(i),Xt',Nc,Nr,Nb,vaccin_perd,vaccinFraction1,vaccinFraction2,Vbirth,VE,e_AO,e_ROS,e_RSI,e_AOS,e_ASI,Optimal,Pwlaw,eta,pi_O,pi_G,gama_O,gama_G,TranProb_O_OS,TranProb_G_OS,TranProb_G_SI,Xi_t, Xi_D,Z,Rou0,C_OS,C_SI,Psi);
       % Store stratified forces of infection (age x risk)at time t(i)
       lamOralOral(:,:,i)=lamOO;% oral acquisition from oral source
       lamGenitalOral(:,:,i)=lamGO;% oral acquisition from genital source
       lamGenitalGenital(:,:,i)=lamGG;% genital acquisition from genital source
       lamOralGenital(:,:,i)=lamOG;% genital acquisition from oral source
       % Total FoI by acquisition route (sum of sources)
       lamOral(:,:,i)=lamOO+lamGO;
       lamGenital(:,:,i)=lamOG+lamGG;
       % Incidence by age (sum across risk groups)
       IncidenceGenital(i,:)=(sum(((lamGenital(:,:,i).*(Susceptible(:,:,i)+SusceptibleWPS(:,:,i)+SusceptibleWB(:,:,i)))+((1-VE)*lamGenital(:,:,i).*(SusceptiblePS(:,:,i)+SusceptibleB(:,:,i)))),2))'; 
       IncidenceOral(i,:)=(sum(((lamOral(:,:,i).*(Susceptible(:,:,i)+SusceptibleWPS(:,:,i)+SusceptibleWB(:,:,i)))+((1-VE)*lamOral(:,:,i).*(SusceptiblePS(:,:,i)+SusceptibleB(:,:,i)))),2))'; 
   
       % �Vaccination� summary outputs
       EffectiveVaccinaBirth(i)=EffvBirth;% % Number of vaccinated individuals at birth (neonatal)
       EffectiveVaccinePrimarySeries(i)=EffvPS;%  number of  vaccinated individuals with primary-series vaccination
       EffectiveVaccineBoost(i)=EffVboost;%  number of vaccinated individuals with booster vaccination
       
    end
%% Calculation of incidence rate and vaccinated counts per year
IncG=sum(IncidenceGenital,2);
IncO=sum(IncidenceOral,2);
IncidenceGenitalyear(1)=IncG(1);
IncidenceOralyear(1)=IncO(1);
EffectiveVaccinaBirthyear(1)=EffectiveVaccinaBirth(1);
EffectiveVaccinePrimarySeriesyear(1)=EffectiveVaccinePrimarySeries(1);
 EffectiveVaccineBoostyear(1)=EffectiveVaccineBoost(1);
for j=t0+1:tf
IncidenceGenitalyear(j-t0+1) =trapz(IncG(2*(j-t0)+1:2*(j-t0+dt)+1));
IncidenceOralyear(j-t0+1) =trapz(IncO(2*(j-t0)+1:2*(j-t0+dt)+1));
EffectiveVaccinaBirthyear(j-t0+1)=trapz(EffectiveVaccinaBirth(2*(j-t0)+1:2*(j-t0+dt)+1));
EffectiveVaccinePrimarySeriesyear(j-t0+1)=trapz(EffectiveVaccinePrimarySeries(2*(j-t0)+1:2*(j-t0+dt)+1));
EffectiveVaccineBoostyear(j-t0+1)=trapz(EffectiveVaccineBoost(2*(j-t0)+1:2*(j-t0+dt)+1));
end
% Total susceptible population (all vaccination/immunity statuses),
SusceptibleTotal=reshape(sum(sum(Susceptible+SusceptiblePS+SusceptibleB+SusceptibleWPS+SusceptibleWB,2)),length(t),1);
% Incidence rates per year
IncidenceGenitalrate= IncidenceGenitalyear' ./SusceptibleTotal(1:2:end);
IncidenceOralrate=  IncidenceOralyear'./SusceptibleTotal(1:2:end);  
%% save results
save('Withoutvaccin.mat','PrevalenceTotal','IncidenceGenitalyear','IncidenceOralyear','IncidenceGenitalrate','IncidenceOralrate','EffectiveCoverage','EffectiveVaccinaBirthyear','EffectiveVaccinePrimarySeriesyear','EffectiveVaccineBoostyear','VaccineCoverage','t')
       
   
%% extruct values:


HSV1OralInfected_Age=squeeze(sum(IOral,2)+sum(AOral,2));% Oral HSV-1 infections by age
OralPrevalence_Age=100*HSV1OralInfected_Age./PopulationTotal_Age;

%%
% ---------------------------------------------------------
% Oral HSV-1 infections & prevalence by age (1�10) in ONE table
% ---------------------------------------------------------
ages = (1:10);  % 10x1
time_index = (2020.5 - t0 + 0.5) * 2;
infected_values   = HSV1OralInfected_Age(time_index, ages) ./ 1e6;
prevalence_values = OralPrevalence_Age(time_index, ages);

% Force column vectors (works whether outputs are row or column)
infected_values   = infected_values(:);
prevalence_values = prevalence_values(:);

% Now dimensions match: 10x1, 10x1, 10x1
results = [ages' infected_values prevalence_values];

results_table = array2table(results, ...
    'VariableNames', {'Age', 'Oral_HSV1_Infections_Millions', 'Oral_HSV1_Prevalence'});

disp(results_table)

% TotalOralInfections0_49=sum(HSV1OralInfected_Age(time_index ,ages))./1e6;
% OralPrevalence0_49=TotalOralPrevalence_0_49(time_index);
% results_table1 = table("0-10",TotalOralInfections0_49,OralPrevalence0_49, ...
%     'VariableNames', {'Total', 'Oral_HSV1_Infections_Millions', 'Oral_HSV1_Prevalence'});
% disp(results_table1)





% ---------------------------------------------------------
% Genital HSV-1 infections & prevalence by age (4�10) in ONE table
% ---------------------------------------------------------
ages = (4:10); 
time_index = (2020.5 - t0 + 0.5) * 2;
HSV1GenitalInfectedAge=HSV1GenitalInfected_Age_S+HSV1GenitalInfected_Age_As;



infected_values   = HSV1GenitalInfectedAge(time_index, ages) ./ 1e6;
prevalence_values = GenitalPrevalence_Age(time_index, ages);


infected_values   = infected_values(:);
prevalence_values = prevalence_values(:);
results = [ages' infected_values prevalence_values];
results_table = array2table(results, ...
    'VariableNames', {'Age', 'Genital_HSV1_Infections_Millions', 'Genital_HSV1_Prevalence'});
disp(results_table)
TotalGenitalInfections15_49=sum(HSV1GenitalInfectedAge(time_index ,ages))./1e6;


genitalPrevalence15_49=100*(sum(HSV1GenitalInfectedAge(time_index ,ages))./sum(PopulationTotal_Age(time_index ,ages)));
results_table1 = table("4-10",TotalGenitalInfections15_49,genitalPrevalence15_49, ...
    'VariableNames', {'Total', 'Genital_HSV1_Infections_Millions', 'Genital_HSV1_Prevalence'});
disp(results_table1)






















Totalincidence= IncidenceOral+ IncidenceGenital; 

% ---------------------------------------------------------
% HSV-1 incidence & population incidence by age (1�10) in ONE table
% ---------------------------------------------------------
ages = (1:10);  % 10x1
time_index = (2020.5- t0 + 0.5) * 2;
Incidence= Totalincidence(time_index, ages) ./1e6;
PopulationIncidence = 100*((Totalincidence(time_index,ages))./PopulationTotal_Age(time_index,ages));
Incidence_values   = Incidence(:);
PopulationIncidence_values = PopulationIncidence(:);
results = [ages' Incidence_values PopulationIncidence_values];
results_table = array2table(results, ...
    'VariableNames', {'Age','Incidence_2020', 'PopulationIncidence_2020'});
disp(results_table)
TotalIncidence0_49=sum(Incidence);
TotalPopulationIncidence0_49=100*(sum(Totalincidence(time_index,ages))./sum(PopulationTotal_Age(time_index,ages)))
results_table1 = table("0-10",TotalIncidence0_49,TotalPopulationIncidence0_49, ...
     'VariableNames', {'Total','Incidences_2020', 'PopulationIncidence'});
disp(results_table1)

%% incidence rate per year per age
SusPopulation_Age=squeeze(sum(S,2));
IncRateAge=Totalincidence./SusPopulation_Age;
100*IncRateAge(time_index,ages);