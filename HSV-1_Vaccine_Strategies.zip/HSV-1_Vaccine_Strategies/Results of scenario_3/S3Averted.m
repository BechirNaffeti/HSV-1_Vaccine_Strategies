clear all
close all 
clc
load('Withoutvaccin.mat')

PrevalenceTotalWV=PrevalenceTotal;
IncidenceGenitalyearWV=IncidenceGenitalyear;
IncidenceOralyearWV=IncidenceOralyear;
IncidenceGenitalrateWV=IncidenceGenitalrate;
IncidenceOralrateWV=IncidenceOralrate;
EffectiveVaccinaBirthWV=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesWV=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostWV=EffectiveVaccineBoostyear;
TotalinfectedWV=IncidenceGenitalyearWV+IncidenceOralyearWV;     
TotalvaccieWV=EffectiveVaccinaBirthWV+EffectiveVaccinePrimarySeriesWV+EffectiveVaccineBoostWV;




load('Scenario1VE50.mat')
PrevalenceTotalVE50=PrevalenceTotal;
IncidenceGenitalyearVE50=IncidenceGenitalyear;
IncidenceOralyearVE50=IncidenceOralyear;
IncidenceGenitalrateVE50=IncidenceGenitalrate;
IncidenceOralrateVE50=IncidenceOralrate;
EffectiveVaccinaBirthVE50=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE50=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE50=EffectiveVaccineBoostyear;
TotalinfectedVE50=IncidenceGenitalyearVE50+IncidenceOralyearVE50;   
TotalvaccieVE50=EffectiveVaccinaBirthVE50+EffectiveVaccinePrimarySeriesVE50+EffectiveVaccineBoostVE50;



load('Scenario1VE70.mat')
PrevalenceTotalVE70=PrevalenceTotal;
IncidenceGenitalyearVE70=IncidenceGenitalyear;
IncidenceOralyearVE70=IncidenceOralyear;
IncidenceGenitalrateVE70=IncidenceGenitalrate;
IncidenceOralrateVE70=IncidenceOralrate;
EffectiveVaccinaBirthVE70=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE70=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE70=EffectiveVaccineBoostyear;
TotalinfectedVE70=IncidenceGenitalyearVE70+IncidenceOralyearVE70;   
TotalvaccieVE70=EffectiveVaccinaBirthVE70+EffectiveVaccinePrimarySeriesVE70+EffectiveVaccineBoostVE70;


load('Scenario1VE90.mat')
PrevalenceTotalVE90=PrevalenceTotal;
IncidenceGenitalyearVE90=IncidenceGenitalyear;
IncidenceOralyearVE90=IncidenceOralyear;


IncidenceGenitalrateVE90=IncidenceGenitalrate;
IncidenceOralrateVE90=IncidenceOralrate;
EffectiveVaccinaBirthVE90=EffectiveVaccinaBirthyear;
EffectiveVaccinePrimarySeriesVE90=EffectiveVaccinePrimarySeriesyear;
EffectiveVaccineBoostVE90=EffectiveVaccineBoostyear;


TotalinfectedVE90=IncidenceGenitalyearVE90+IncidenceOralyearVE90;   
TotalvaccieVE90=EffectiveVaccinaBirthVE90+EffectiveVaccinePrimarySeriesVE90+EffectiveVaccineBoostVE90;





t0=1750;
tf=2100;
dt=0.5;



years1=2020:2100;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(years1)
    
    AvertInfection50(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE50(2030-t0+1:years1(j)-t0+1));
   
    
    AvertInfection70(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE70(2030-t0+1:years1(j)-t0+1));
     
    
    AvertInfection90(j)=sum(TotalinfectedWV(2030-t0+1:years1(j)-t0+1)-TotalinfectedVE90(2030-t0+1:years1(j)-t0+1));
   
    
    
    
end
save('S3Averted.mat','AvertInfection50','AvertInfection70','AvertInfection90')